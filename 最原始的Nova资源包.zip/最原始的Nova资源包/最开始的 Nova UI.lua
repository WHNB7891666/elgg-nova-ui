--[[
================================================================================
  最开始的 Nova UI —— 纯 UI 示例
  来源：未做任何玻璃改造之前的 Nova 原版界面（纯色卡片风格，无模糊、无高斯、无折射）
  资源包：/sdcard/最原始的Nova资源包（与脚本配套，RootPath 已指向它）
  用途：只当 UI 模板用。删掉了全部业务功能（美化注入、防闪、过检测、挂进程、
        读写枪械表、卡密联网验证），只保留界面框架 + 控件演示。
================================================================================

【一、界面是怎么来的】

  分页 = {
      {                                   -- 第 1 个分区（左侧导航第 1 项）
          ["分区名字"] = "控件",
          ["二级分页"] = {                -- 这个分区下面的 tab
              {
                  ["分页名字"] = "基础",   -- tab 名字
                  ['分页列数'] = 1,       -- 1 = 单列列表；2 = 两列网格
                  ["分页菜单"] = { ... }   -- 这一页里放的控件，从上往下排
              },
              { ... 第 2 个 tab ... },
          }
      },
      { ... 第 2 个分区 ... },
  }

  启动：uistart(分页)


【二、内置控件（都是 table 构造器，直接塞进「分页菜单」里就行）】

  CAtext("文字", 颜色, 字号)                     -- 静态文字
  CAFreshText("初始文字", "id", 颜色, 字号)       -- 可被 SetText 改的文字
  CAbutton("按钮名字", function() ... end)        -- 按钮
  CAswitch("开关名字", 开回调, 关回调, "副标题")   -- 开关（胶囊）
  CAswitch2(同上)                                 -- 开关（字体兼容那一款）
  CAintcheck("名字", 开回调, 关回调)              -- 勾选式开关
  CAEdit("名字", "占位提示")                      -- 输入框，取值 CAGetEdit("名字")
  CAseek("名字", "唯一id", 最小, 最大, 当前值, 步长, nil, 回调)   -- 滑块
  CARange("名字", "唯一id", 最小, 最大, 当前值, 步长, 回调)        -- 范围滑块
  CAboxLite("分组标题", {                         -- 可折叠分组
      { name = "子项1", func = function() ... end, off = function() ... end },
      { name = "子项2", func = function() ... end },
  }, "右侧小字")
  -- 下面这三个返回的是“布局 table”（[1]=LinearLayout），不是菜单项：
  -- 它们不能直接写进 ["分页菜单"]，要包一层 { LinearLayout, ..., CAcheck(...) } 当普通布局用，
  -- 或者自己给 createView 加一个分支。
  --   CAcheck("名字", { "选项1", "选项2" })     多选
  --   CAradio({ "单选1", "单选2" })             单选
  --   CAintcheck("名字", 开回调, 关回调)        勾选

  颜色用 0xAARRGGBB，例如 0xFF1D1D1F = 不透明深灰，0xFFCC0000 = 红色。


【三、填内容（最常见的三种改法）】

  1) 换分区名 / tab 名：直接改 ["分区名字"] 和 ["分页名字"] 的字符串。

  2) 往一页里加东西：在那一页的 ["分页菜单"] 里加一行，例如
         ["分页菜单"] = {
             CAtext("新的说明文字", 0xFF6B7280, 12),
             CAbutton("新按钮", function() 提示("跑起来了") end),
         }

  3) 加一整个新分区：复制最外面那个 { ["分区名字"] = ..., ["二级分页"] = { ... } },
     粘到 分页 = { } 里的任意位置，改名字即可。（左侧导航会自动多一项）


【四、新建一种全新的控件（原来没有的类型）】

  第 1 步：在文件开头 TYPE_xxx 那排常量下面加一个编号，例如
         TYPE_MYCTRL = 12

  第 2 步：写一个构造器，返回一个带 type 的 table：
         function CAmyctrl(txt, func)
             return { type = TYPE_MYCTRL, name = txt, func = func }
         end

  第 3 步：在 uistart 里的 createView 函数中，照着 TYPE_BUTTON 那一段加一个分支：
         elseif viewType == TYPE_MYCTRL then
             view = luajava.loadlayout({
                 LinearLayout,
                 layout_width = "match_parent",
                 layout_height = "wrap_content",
                 __onFinish = function(v)
                     v.setOnClickListener({ onClick = function() func() end })
                 end,
                 { TextView, text = item.name, textSize = "13sp" }
             })

  第 4 步：在 分页菜单 里就能直接写 CAmyctrl("试一下", function() 提示("hi") end)。


【五、资源包（必须配套）】

  本示例配套的资源包目录：
      /sdcard/最原始的Nova资源包/
          ├─ 图片/            alifont（字体）、Palette、heix、sou、gcmm、
          │                   nachosleep2、cb3ff1.jpg（悬浮窗图标）、NoFont.txt
          └─ nova_icon/       脚本图标（MT 管理器里用的那几张 png）

  脚本里 RootPath 就指向这个目录：
      RootPath='/sdcard/最原始的Nova资源包'
      SavePath=RootPath..'/图片/'

  想把资源包挪到别的地方，只改 RootPath 这一行就行，其余代码不用动。
  资源包里没有 LiquidGlass.dex——这一版不含玻璃，不需要它。


【六、注意】
  - 这一版没有玻璃（LiquidGlass）那一套，玻璃相关代码一行都没带过来。
  - 卡密验证已彻底去掉（Nova弹出卡密层 不再被调用），进去直接是面板。
  - 脚本开头那句正文自检（Nova自检）已去掉调用，随便改都不会被锁。
================================================================================
]]

-- ==== 正文校验（脚本第一条语句，改动/重写即静默退出） ====
local Nova_标记 = 'Nova|导妈|自研|v60'
local Nova_原 = {
    sf = string.format, sg = string.gsub, ss = string.sub, sb = string.byte,
    sr = string.rep, ts = tostring, tn = tonumber, tp = type,
    pr = pairs, ip = ipairs, pc = pcall, xp = xpcall,
    sm = setmetatable, gm = getmetatable, ld = loadstring or load, ox = os.exit
}
function Nova自检()
    if type(gg) ~= 'table' then return false end
    if not (gg.getValues and gg.setValues and gg.getRangesList and gg.alert) then return false end
    string.format, string.gsub, string.sub, string.byte = Nova_原.sf, Nova_原.sg, Nova_原.ss, Nova_原.sb
    string.rep = Nova_原.sr
    _G.tostring, _G.tonumber, _G.type = Nova_原.ts, Nova_原.tn, Nova_原.tp
    _G.pairs, _G.ipairs, _G.pcall, _G.xpcall = Nova_原.pr, Nova_原.ip, Nova_原.pc, Nova_原.xp
    _G.setmetatable, _G.getmetatable = Nova_原.sm, Nova_原.gm
    _G.loadstring, _G.load = Nova_原.ld, Nova_原.ld
    _G.os.exit = Nova_原.ox
    local h = 7
    for i = 1, #Nova_标记 do h = (h * 31 + Nova_原.sb(Nova_标记, i)) % 4294967291 end
    if h ~= 964521863 then return false end
    return true
end
RootPath='/sdcard/最原始的Nova资源包'   -- 本示例配套资源包（脚本和资源包要配套）

TYPE_TEXT = 0
TYPE_IMAGE = 1
TYPE_BUTTON=2
TYPE_SWITCH=3
TYPE_CHECK=4
TYPE_RADIO=5
TYPE_BOX=6
TYPE_SLIDER=7
TYPE_EDIT=8
TYPE_FRESHTEXT=9
TYPE_RANGE=10
TYPE_CHECKBOX=11

local material3 = elgg.import('material3')
context=material3:getContext()
M3context=context
context.setTheme(0x7f090069)
import('android.content.res.ColorStateList')
import 'android.graphics.RectF'
RadTint=ColorStateList({
    {android.R.attr.state_checked},
    {-android.R.attr.state_checked},
            {},
        }, {
            0xFFEA4335,
            0xFFEA4335,
            0xFFEA4335
        })
local marg=luajava.new(RectF,10,10,10,10)
local swcDraw=ColorStateList({
	{android.R.attr.state_checked},
	{-android.R.attr.state_checked},
},
{
	'0xFFEA4335',
	'0xFFE6E6E6',
})
local swcThumb=ColorStateList({
	{android.R.attr.state_checked},
	{android.R.attr.state_pressed},
	{-android.R.attr.state_pressed},
},
{
	0xffffffff,
	0xffeeeeee,
	0xffffffff
})
SavePath=RootPath..'/图片/'
local sldtktt=ColorStateList({{},},{0xFFEA4335})
local sldiktt=ColorStateList({{},},{'0xFFE6E6E6'})
local sldsm=ColorStateList({{},},{'0xffffffff'})
import 'android.graphics.Bitmap'
import 'android.graphics.BitmapFactory'
import 'android.renderscript.Allocation'
import 'android.renderscript.Element'
import 'android.renderscript.RenderScript'
import 'android.renderscript.ScriptIntrinsicBlur'
import 'android.graphics.Canvas'
import 'android.graphics.Rect'
import "android.animation.ObjectAnimator"
import "android.view.animation.Animation"
import "android.animation.ArgbEvaluator"
import "android.animation.ValueAnimator"
import "android.graphics.Color"
import'com.google.android.material.divider.MaterialDivider'
import'com.google.android.material.progressindicator.*'
import'com.google.android.material.dialog.MaterialAlertDialogBuilder'
import'com.google.android.material.tabs.TabItem'
import'androidx.coordinatorlayout.widget.CoordinatorLayout'
import'com.google.android.material.button.MaterialButton'
import'androidx.appcompat.widget.LinearLayoutCompat'
import'com.google.android.material.slider.Slider'
import 'com.google.android.material.slider.RangeSlider'
import'com.google.android.material.materialswitch.MaterialSwitch'
import'com.google.android.material.card.MaterialCardView'
import'androidx.transition.Transition'
import'androidx.transition.Scene'
import'androidx.transition.TransitionManager'
import'androidx.transition.TransitionSet'
import'androidx.transition.ChangeBounds'
import'androidx.transition.Fade'
import'androidx.constraintlayout.motion.widget.MotionLayout'
import"android.view.animation.AccelerateInterpolator"
import"android.view.animation.DecelerateInterpolator"
import"androidx.interpolator.view.animation.FastOutLinearInInterpolator"
import"androidx.interpolator.view.animation.LinearOutSlowInInterpolator"
import"android.view.animation.OvershootInterpolator"
import 'android.animation.ValueAnimator$AnimatorUpdateListener'
import 'android.animation.TypeEvaluator'
import 'android.graphics.PorterDuff'
import 'android.graphics.PorterDuffColorFilter'
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "android.content.*"
import "java.util.*"
import "java.lang.*"
import "android.*"
import "android.graphics.drawable.*"
import "android.graphics.PixelFormat"
import "android.view.animation.RotateAnimation"
import "android.view.animation.BounceInterpolator"
import "android.ext.*"
import "android.ext.MainService"
import "android.graphics.drawable.GradientDrawable"
import "android.graphics.Typeface"
import "java.io.File"
import "luaj.lib.ModLib"
import "android.ext.Tools"
import 'android.graphics.RectF'
import "android.animation.FloatEvaluator"
context = activity
function getBG(colors, radiu, bk1, bk2)
    local GradientDrawable = luajava.bindClass("android.graphics.drawable.GradientDrawable")
    local drawable = GradientDrawable.new()
    drawable.setGradientType(GradientDrawable.LINEAR_GRADIENT)
    if type(colors)=="table" then
        drawable.setColors(luajava.toArray(colors,'int'))
    else
        drawable.setColors(luajava.toArray({colors,colors},'int'))
    end
    if type(radiu)=='table' then
    	drawable.setCornerRadii({radiu[1],radiu[1],radiu[2],radiu[2],radiu[3],radiu[3],radiu[4],radiu[4]})
    else
	    drawable.setCornerRadii({radiu,radiu,radiu,radiu,radiu,radiu,radiu,radiu})
    end
    if bk1 ~= nil and bk2 ~= nil then drawable.setStroke(bk1, bk2) end
    return drawable
end
function getHorizontalBG(colors, radiu, bk1, bk2)
    local GradientDrawable = luajava.bindClass("android.graphics.drawable.GradientDrawable")
    local drawable = GradientDrawable.new()
    drawable.setOrientation(GradientDrawable.Orientation.LEFT_RIGHT)
    drawable.setGradientType(GradientDrawable.LINEAR_GRADIENT)
    if type(colors)=="table" then
        drawable.setColors(luajava.toArray(colors,'int'))
    else
        drawable.setColors(luajava.toArray({colors,colors},'int'))
    end
    if type(radiu)=='table' then
    	drawable.setCornerRadii({radiu[1],radiu[1],radiu[2],radiu[2],radiu[3],radiu[3],radiu[4],radiu[4]})
    else
	    drawable.setCornerRadii({radiu,radiu,radiu,radiu,radiu,radiu,radiu,radiu})
    end
    if bk1 ~= nil and bk2 ~= nil then drawable.setStroke(bk1, bk2) end
    return drawable
end
file.checkDir(RootPath)
file.checkDir(SavePath)
luajava.runUiThread=luajava.runOnUiThread
luajava.loadlayout=loadlayout
luajava.startThread=callAsyncTask
local dpi=context.getResources().getDisplayMetrics().density
window = context.getSystemService("window")
vibra = context.getSystemService(Context.VIBRATOR_SERVICE)
audi = context.getSystemService("audio")
local rs=context:getResources():getDisplayMetrics()
local rs=tostring(rs)
local rs=string.gsub(rs,',',';')
local rs=string.gsub(rs,'DisplayMetrics','')

rs=load('return '..rs)()
local dheight=rs.height
local dwidth=rs.width
if tonumber(dheight)==nil then
	dwidth=1340
	dheight=2300
end
context=M3context
function getpx(x)
	if type(x)=='string' then
		if string.find(x,'dp') then
			x=string.gsub(x,'dp','')
			x=tonumber(x)
		end
		return x*dpi
	else
		return x
	end
end
function getdp(x)
	if type(x)=='number' then
		return x/dpi..'dp'
	else
		return x
	end
end
DP280=getpx('280dp')
DP320=getpx('400dp')
function guid()
    seed = {
        'e','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f'
    }
    tb = {}
    for i = 1,32 do
        table.insert(tb,seed[math.random(1,16)])
    end
    sid = table.concat(tb)
    return string.format('%s%s%s',
    string.sub(sid,1,8),
    string.sub(sid,10,16))
end

local mObjectAnimator
local dObjectAnimator

ljids={}
function panduan(rec) fille,err = io.open(rec) if fille == nil then return false else return true end end
import 'android.graphics.Bitmap'
import 'android.graphics.Canvas'
import 'android.graphics.Rect'

ViewFakeTransition = loadlayout({
    FrameLayout,
    visibility = 'gone',
    elevation = '10dp',
    {
        ImageView,
        layout_height = 'match_parent',
        layout_width = 'match_parent'
    },
    {
        ImageView,
        layout_height = 'match_parent',
        layout_width = 'match_parent'
    }
})

local nothing = function()
end
function View2Bitmap(view, isblur)
    local width = view.getMeasuredWidth()
    local height = view.getMeasuredHeight()
    if width == 0 then
        width = 1
        height = 1
    end
    local bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
    local canvas = Canvas(bitmap)
    canvas.translate(-view.getScrollX(), -view.getScrollY())
    view.draw(canvas)
    if isblur then
        return getBlur(bitmap)
    else
        return bitmap
    end
end
function CAViewInfo(v)
    local info = luajava.astable(v.getLocationOnScreen())
    local start = luajava.astable(starv.getLocationOnScreen())
    return { info[1] - (mainLayoutParams.x - mainLayoutParams.width / 2) - start[1], info[2] -
    (mainLayoutParams.y - mainLayoutParams.height / 2) - start[2] }
end
function CATransition(view1, view2, duration, polator, func, func2, keep)
    func = func or nothing
    func2 = func2 or nothing
    if type(view1) == 'string' then
        view1 = luajava.getIdView(view1)
    end
    if type(view2) == 'string' then
        view2 = luajava.getIdView(view2)
    end
    if view1.getVisibility() == View.GONE then
        return
    end
    if view2.getVisibility() == View.GONE then
        return
    end
    if ViewFakeTransition.getVisibility() == View.VISIBLE then
        return
    end
    ViewFakeTransition.setVisibility(View.VISIBLE)
    local P1 = CAViewInfo(view1)
    local P2 = CAViewInfo(view2)
    local DrawingView1, DrawingView2 = ViewFakeTransition.getChildAt(0), ViewFakeTransition.getChildAt(1)
    DrawingView1.setImageBitmap(View2Bitmap(view1))
    DrawingView1.setAlpha(1)
    DrawingView2.setImageBitmap(View2Bitmap(view2))
    DrawingView2.setAlpha(0)
    local height1, width1, height2, width2, P11, P12, P21, P22 = view1.getMeasuredHeight(), view1.getMeasuredWidth(),
        view2.getMeasuredHeight(), view2.getMeasuredWidth(), P1[1], P1[2], P2[1], P2[2]
    if not keep then
        view1.setVisibility(View.INVISIBLE)
    end
    view2.setVisibility(View.INVISIBLE)
    local VP = ViewFakeTransition.getLayoutParams()
    VP.height = height1
    VP.width = width1
    VP.setMargins(P11, P12, 0, 0)
    ViewFakeTransition.setLayoutParams(VP)
    local animator = ValueAnimator.ofObject(FloatEvaluator(), {0, 1}).setDuration(duration)
    animator.setInterpolator(polator)
    local listener = luajava.createProxy('android.animation.ValueAnimator$AnimatorUpdateListener', {
        onAnimationUpdate = function(animation)
            local animatedProgress = animation.getAnimatedValue()
            if animatedProgress > 1 then
                animatedProgress = 1 + (animatedProgress - 1) / 6
            end
            VP.height = height1 + (height2 - height1) * animatedProgress
            VP.width = width1 + (width2 - width1) * animatedProgress
            VP.setMargins(P11 + (P21 - P11) * animatedProgress, P12 + (P22 - P12) * animatedProgress, 0, 0)
            ViewFakeTransition.setLayoutParams(VP)
            DrawingView1.setAlpha(1 - animatedProgress)
            DrawingView2.setAlpha(animatedProgress)
        end
    })
    animator.addUpdateListener(listener)
    local listener = luajava.createProxy('android.animation.Animator$AnimatorListener', {
        onAnimationStart = func,
        onAnimationEnd = function()
            view2.setVisibility(View.VISIBLE)
            ViewFakeTransition.setVisibility(View.GONE)
            window.updateViewLayout(xfc, mainLayoutParams)
            view2.setVisibility(View.VISIBLE)
            func2()
        end,
        onAnimationCancel = function(animator)

        end
    })
    animator.addListener(listener)
    animator.start()
end
function elggDev(t)
    luajava.startThread(function()
        gg.alert(tostring(t))
    end)
end

local _toast就绪 = false
local function _初始化提示()
    if _toast就绪 then return true end
    pcall(function()
        if type(elgg) == "table" and type(elgg.import) == "function" then elgg.import("toast") end
        if type(toast) == "table" then _toast就绪 = true end
    end)
    return _toast就绪
end
_初始化提示()

local 最近文字, 最近时间 = nil, -10
local function 重复(文字)
    local now = os.clock()
    if 最近文字 == 文字 and (now - 最近时间) < 0.35 then
        最近时间 = now
        return true
    end
    最近文字, 最近时间 = 文字, now
    return false
end

function 弹主题(文字, 类型)
    _初始化提示()
    if _toast就绪 then
        local f = toast[类型 or "hint"]
        if type(f) == "function" then
            if pcall(f, 文字) then return true end
        end
        if type(toast.hint) == "function" then
            if pcall(toast.hint, 文字) then return true end
        end
    end
    return false
end

function 提示(文字, 类型)
    文字 = tostring(文字 == nil and "" or 文字)
    if 重复(文字) then return true end
    弹主题(文字, 类型 or "hint")
    return true
end

function 提示类型(文字)
    local t = tostring(文字 or "")
    if t:find("成功", 1, true) or t:find("完成", 1, true) or t:find("已生成", 1, true) or t:find("已保存", 1, true) then
        return "success"
    elseif t:find("失败", 1, true) or t:find("出错", 1, true) or t:find("错误", 1, true)
        or t:find("请先", 1, true) or t:find("未", 1, true) or t:find("没有", 1, true) then
        return "error"
    elseif t:find("警告", 1, true) or t:find("注意", 1, true) or t:find("耐心", 1, true) then
        return "warn"
    end
    return "hint"
end

function 智能提示(文字)
    local t = tostring(文字 == nil and "" or 文字)
    if 重复(t) then return true end
    return 弹主题(t, 提示类型(t))
end

function 色到类型(色)
    local s = tostring(色 or ""):gsub("#", ""):gsub("^0[xX]", "")
    local n = tonumber(s, 16)
    if n == nil then return "hint" end
    if n > 0xFFFFFF then n = n % 0x1000000 end
    local r = math.floor(n / 0x10000) % 0x100
    local g = math.floor(n / 0x100) % 0x100
    local b = n % 0x100
    if r >= 160 and r > g and r > b then return "error" end
    if g >= 120 and g >= r and g > b then return "success" end
    if r >= 160 and g >= 120 then return "warn" end
    return "hint"
end

function 彩提示(文字, 色)
    local t = tostring(文字 == nil and "" or 文字)
    if 重复(t) then return true end
    return 弹主题(t, 色到类型(色))
end

function checkimg(tmp, ii)
	if panduan(SavePath .. tmp[1], false) ~=true  then
		智能提示("初次启动,正在下载资源" .. ii .. "/" .. #ckimg .. "\n请耐心等待")
		file.download(tmp[2], SavePath .. tmp[1])
	end
end
if panduan(SavePath..'NoFont.txt')~=true then
    file.write(SavePath..'NoFont.txt','0')
end
NoFont=file.read(SavePath..'NoFont.txt')=='1' and true or false
ckimg = {
	{'836253849','http://106.53.184.168:802/api/v3/file/get/95951/836253849?sign=MRXjNN6q7TkRkbDbZ0sgNLeP6ISxTn3vvcLL7ZLQMZQ%3D%3A0'},
	{'1360640248','http://106.53.184.168:802/api/v3/file/get/95950/1360640248?sign=uT0pihNidbKMfJZC6nPFuLsXjThK9R7HxFd-CtKloWM%3D%3A0'},
	{'238759315','http://106.53.184.168:802/api/v3/file/get/95949/238759315?sign=-AeRn6Z9xYFv9kxyqsm0puOBFsZPmSuw4I7RXVTRNr4%3D%3A0'},
	{'1884812492','http://106.53.184.168:802/api/v3/file/get/95948/1884812492?sign=Sr5_s-X6YfmfevSkxH6ssx5zfzDnR65BGIM9-yiMGhU%3D%3A0'},
	{'531183638','http://106.53.184.168:802/api/v3/file/get/95945/531183638?sign=vnaEayt8gx4TH9gqj1KTDHOz2AHOOE_5KV-QGH1zlvo%3D%3A0'},
	{'524085136','http://106.53.184.168:802/api/v3/file/get/95944/524085136?sign=ff74lQuoSuK4phIBNk8OgLSOiUiOOk1i9sLpIhP8b6E%3D%3A0'},
	{'1316430524','http://106.53.184.168:802/api/v3/file/get/95943/1316430524?sign=g3LeHKIaPiGCSt5ndRq1xISMGMxA2krBNgjPyvU6zCo%3D%3A0'},
	{'unlove','http://106.53.184.168:802/api/v3/file/get/95942/unlove?sign=qBAgerNaf-2_6Tn0GyzpRssszGDCZDBN9pVeliTLTDI%3D%3A0'},
    {'love','http://106.53.184.168:802/api/v3/file/get/95940/love?sign=_m-Q_fmfUhE6hS-SCebITF4pDcBuAWoosUUOoO3GknI%3D%3A0'},
    {'heir','http://wss.wigwy.xyz/api/get/yjb/1077'},
    {'heix','http://wss.wigwy.xyz/api/get/yjb/866'},
    {'sou','http://wss.wigwy.xyz/api/get/yjb/862'},
	{'con2','http://wss.wigwy.xyz/api/get/yjb/840'},
    { 'disk',         'http://wss.wigwy.xyz/api/get/yjb/1463' },
    {'alifont','http://wss.wigwy.xyz/api/get/yjb/1635'},
    {'PlayIcon','http://wss.wigwy.xyz/api/get/yjb/1572'},
    {'PauseIcon','http://wss.wigwy.xyz/api/get/yjb/1573'},
    { 'Palette',      'http://wss.wigwy.xyz/api/get/yjb/1467' },
    {'mynbg','http://wss.wigwy.xyz/api/get/yjb/1564'},
    {'shizukuthumb2','http://wss.wigwy.xyz/api/get/yjb/1631'},
    {"nachosleep1",'http://wss.wigwy.xyz/api/get/yjb/1629'},
    {"nachosleep2",'http://wss.wigwy.xyz/api/get/yjb/1630'},
    {'gcmm','http://wss.wigwy.xyz/api/get/yjb/1637'},
}
for i = 1,#ckimg do
jindu = i
checkimg(ckimg[i],i)
end
alifont = Typeface.createFromFile(luajava.newInstance("java.io.File", SavePath..'alifont'))

compile(SavePath..'Palette')
import 'androidx.palette.graphics.Palette'
import 'androidx.recyclerview.widget.RecyclerView'
import 'androidx.recyclerview.widget.LinearLayoutManager'
import 'androidx.recyclerview.widget.GridLayoutManager'
import 'androidx.recyclerview.widget.StaggeredGridLayoutManager'
import 'androidx.recyclerview.widget.RecyclerView$ViewHolder'
import 'androidx.recyclerview.widget.DividerItemDecoration'
import 'androidx.recyclerview.widget.DefaultItemAnimator'
import 'androidx.recyclerview.widget.RecyclerView$RecycledViewPool'
import 'com.changan.CACore.SwitchButton'
import 'com.changan.ChaoXiSiMa.BridgeRecyclerAdapter'
import 'com.changan.ChaoXiSiMa.BridgeRecyclerAdapter$ViewHolder'
import 'com.changan.ChaoXiSiMa.BridgeRecyclerAdapter$ILuaCallbacks'
import 'com.changan.ChaoXiSiMa.LuaRecyclerBridge'
ShowingPage={}
recyclerView = loadlayout({RecyclerView,layout_height='match_parent',
layout_width='match_parent',
__onFinish=function(v)
  v.setVerticalScrollBarEnabled(false)
  v.setOverScrollMode(2)
  v.setClipToPadding(false)
  v.setPadding(0,getpx('2dp'),0,getpx('8dp'))
end,
})
layoutmanager={}

 do
   local ok1 = pcall(function() layoutmanager[1]=LinearLayoutManager(context) end)
   if (not ok1) or layoutmanager[1]==nil then
     layoutmanager[1]=StaggeredGridLayoutManager(1,StaggeredGridLayoutManager.VERTICAL)
   end
 end
 layoutmanager[2]=StaggeredGridLayoutManager(2,StaggeredGridLayoutManager.VERTICAL)
 layoutmanager[3]=StaggeredGridLayoutManager(3,StaggeredGridLayoutManager.VERTICAL)
 layoutmanager[4]=StaggeredGridLayoutManager(4,StaggeredGridLayoutManager.VERTICAL)
 recyclerView.setLayoutManager(layoutmanager[1])
FirstPage=1
colorCard=function(control,startColor,endColor,t)
    luajava.runUiThread(function()
      control.setCardBackgroundColor(startColor)
      local animator=ValueAnimator.ofObject(ArgbEvaluator(),{startColor,endColor}).setDuration(1000)
      local listener=luajava.createProxy('android.animation.ValueAnimator$AnimatorUpdateListener',{
          onAnimationUpdate=function(animation)
              local animatedColor = animation.getAnimatedValue()
              control.setCardBackgroundColor(animatedColor)
          end
      })
      animator.addUpdateListener(listener)
      animator.start()
    end)
end
function TurnPage(x,y,posz)
    if SelectingNum~=x then
        luajava.getIdView('jm'..x..'t').setTextColor(0xFFEA4335)
        luajava.getIdView('jm'..SelectingNum..'t').setTextColor(0xFF6B7280)
        luajava.getIdView('SecondPage'..SelectingNum).setVisibility(View.GONE)
        luajava.getIdView('SecondPage'..x).setVisibility(View.VISIBLE)
        local _pv=luajava.getIdView('SecondPage'..x)
        local _pa=ObjectAnimator.ofFloat(_pv,'alpha',0,1); _pa.setDuration(180); _pa.start()
        local _pt=ObjectAnimator.ofFloat(_pv,'translationX',getpx('16dp'),0)
        _pt.setDuration(240); _pt.setInterpolator(DecelerateInterpolator()); _pt.start()
    end
    fadein(recyclerView,400)
    y=y or SecondPage[x]
    for i=1,#ViewMenus[x] do
        luajava.getIdView(x..'TopSelect'..i).setBackground(TopBG[x][y][1])
        luajava.getIdView(x..'TopSelect'..i).setTextColor(0xFF6B7280)
    end
    luajava.getIdView(x..'TopSelect'..y).setBackground(TopBG[x][y][2])
    luajava.getIdView(x..'TopSelect'..y).setTextColor(0xFFEA4335)
    if FenyeS[x]['二级分页'][y]['懒加载'] and not FenyeS[x]['二级分页'][y]['已加载'] then
        FenyeS[x]['二级分页'][y]['已加载']=true
        ViewMenus[x][y]=FenyeS[x]['二级分页'][y]['懒加载']()
    end
    ShowingPage=ViewMenus[x][y]
    SelectingNum=x
    SecondPage[x]=y
    recyclerView.setLayoutManager(layoutmanager[FenyeS[x]['二级分页'][y]['分页列数'] or 1])
    CAadapter.notifyDataSetChanged()
    if posz~=nil then
        recyclerView.scrollToPosition(posz)
    end
end
RecycledPools=RecyclerView.RecycledViewPool()
local luaImpl = luajava.createProxy('com.changan.ChaoXiSiMa.BridgeRecyclerAdapter$ILuaCallbacks', {
    getItemCount = function()
        return #ShowingPage
    end,
    getItemViewType = function(position)
        -- 兜底：菜单项没写 type（比如把 CAcheck / CAradio / CAintcheck 这种
        -- “布局 table”直接塞进分页菜单）时返回 nil，会让 createView 返回 nil，
        -- RecyclerView 就抛 itemView may not be null 整块崩掉。
        local it = ShowingPage[position+1]
        if it == nil then return TYPE_TEXT end
        if it.type == nil then return TYPE_TEXT end
        return it.type
    end,
    createView = function(parent, viewType)
        -- 整个建视图过程塞进 pcall：缺图片、字体没加载、某个分支报错，
        -- 都不会让 createView 返回 nil（返回 nil → RecyclerView 抛 itemView may not be null）
        local __buildOk, __built = pcall(function()
        local view
        if viewType == TYPE_TEXT then
            view = luajava.loadlayout(
                {
                    TextView,
                    layout_width='match_parent',
                    layout_height='wrap_content',
                    gravity='center_vertical',
                    textSize='13sp',
                    padding={'14dp','4dp','14dp','4dp'},
                    __onFinish = function(v)
                        if NoFont or alifont == nil then return end
                        v.setTypeface(alifont)
                    end,
                }
            )
        elseif viewType == TYPE_FRESHTEXT then
            view = luajava.loadlayout(
                {
                    TextView,
                    layout_width='match_parent',
                    layout_height='wrap_content',
                    gravity='center',
                    textSize='14sp',
                    padding={'10dp','0dp','10dp','0dp'},
                    __onFinish = function(v)
                        if NoFont or alifont == nil then return end
                        v.setTypeface(alifont)
                    end,
                }
            )
        elseif viewType == TYPE_BUTTON then
            view = luajava.loadlayout({
                    LinearLayout,
                    layout_width = "match_parent",
                    gravity = "center_vertical",
                    layout_margin = "1dp",
                    elevation='0dp',
                    layout_marginLeft='6dp',
                    layout_marginRight='6dp',
                    background = NovaBG(0xFFFFFFFF,10,NOVA.line,1),
                    padding="10dp",
                    onClick = function(v)
                        controlWater(v,120)
                        callAsyncTask(ShowingPage[v.getTag()+1].func or nothing)
                    end,
                    {
                        TextView,
                        gravity='center',
                        textColor = '#6B7280',
                        textSize = "12sp",
                        layout_height = "wrap_content",
                        layout_width = "match_parent",
                        __onFinish = function(v)
                        if NoFont or alifont == nil then return end
                        v.setTypeface(alifont)
                        end,
                    }
                })
        elseif viewType == TYPE_SWITCH then
                view = luajava.loadlayout({
                    LinearLayout,
                    layout_width = 'match_parent',
                    gravity = "center_vertical",
                    {
                        LinearLayout,
                        layout_width = 'match_parent',
                        layout_margin = "4dp",
                        gravity = "center_vertical",
                        padding = {
                            "0dp", "2dp", "6dp", "2dp"
                        },
                        {
                            TextView,
                            gravity = "top",
                            text='123',
                            textColor = '#6B7280',
                            textSize = "14sp",
                            layout_width = 'match_parent',
                            layout_weight=1,
                            layout_marginLeft = "10dp",
                            layout_marginRight = "6dp",
                            __onFinish = function(v)
                        if NoFont or alifont == nil then return end
                        v.setTypeface(alifont)
                            end,
                        },
                        {
                            TextView,
                            gravity = "center",
                            layout_height = "match_parent",
                            textSize = "7sp",
                            layout_width = "wrap_content",
                            layout_marginRight='10dp',
                            textColor = "#A5A5A5",
                            __onFinish = function(v)
                                if NoFont or alifont == nil then return end
                                v.setTypeface(alifont)
                            end,
                        },
                        {
                            SwitchButton,
                            __onFinish = function(v)
                                v.setBackRadius(999)
                                v.setThumbColor(swcThumb)
                                v.setBackColor(swcDraw)
                                v.setThumbRadius(999)
                                v.setThumbRangeRatio(1.7)
                                v.setThumbMargin(marg)
                                v.setOnCheckedChangeListener(
                                    {
                                        onCheckedChanged = function(vie, isc)
                                            local Tag=v.getTag()+1
                                            local info=ShowingPage[Tag]
                                            if isc then
                                                ViewMenus[SelectingNum][SecondPage[SelectingNum]][Tag].isChecked = true
                                                ShowingPage[Tag].isChecked = true
                                                local func = info.func1 or function() end
                                                callAsyncTask(func)
                                            else
                                                ViewMenus[SelectingNum][SecondPage[SelectingNum]][Tag].isChecked = false
                                                ShowingPage[Tag].isChecked = false
                                                local func = info.func2 or function() end
                                                callAsyncTask(func)
                                            end
                                        end
                                    })
                            end,
                            layout_width = 'wrap_content',
                            layout_height = 'wrap_content',
                        }
                    },
                })
        elseif viewType == TYPE_RANGE then
            view = luajava.loadlayout({
                LinearLayout,
                layout_width = 'match_parent',
                orientation = 'horizontal',
                gravity = 'center_vertical',
                {
                    LinearLayout,
                    layout_height = '30dp',
                    layout_width = 'match_parent',
                    layout_marginTop = "2dp",
                    layout_marginBottom = "2dp",
                    gravity = "center_vertical",
                    {
                        TextView,
                        padding = { "14dp", "2dp", "0dp", "2dp", },
                        gravity = "top",
                        textColor = '#6B7280',
                        textSize = '14sp',
                        layout_width = 'wrap_content',
                        layout_marginRight = "0dp",
                        text='123',
                        __onFinish = function(v)
                        if NoFont or alifont == nil then return end
                        v.setTypeface(alifont)
                        end,
                    },
                    {
                        TextView,
                        textColor = '#6B7280',
                        layout_width = '40dp',
                        textSize = '14sp',
                        gravity = 'right|center_vertical',
                        layout_height = 'match_parent',
                        __onFinish = function(v)
                        if NoFont or alifont == nil then return end
                        v.setTypeface(alifont)
                        end,
                    },
                    loadlayout({
                        RangeSlider,
                        thumbTrackGapSize = '-10dp',
                        thumbWidth = '20dp',
                        trackHeight = '4dp',
                        trackStopIndicatorSize = '0dp',
                        tickVisible = false,
                        thumbHeight = '25dp',
                        __onFinish = function(v)
                            v.setTrackActiveTintList(sldtktt)
                            v.setTrackInactiveTintList(sldiktt)
                            v.setLabelBehavior(2)
                            v.setCustomThumbDrawable(shizukuthumb2)
                            v.addOnSliderTouchListener({
                                onStopTrackingTouch = function(v)
                                    local var2 = luajava.astable(v.getValues())
                                    local Tag = v.getTag()[1] + 1
                                    local info = ShowingPage[Tag]
                                    info.value = var2
                                    ViewMenus[SelectingNum][SecondPage[SelectingNum]][Tag] = info
                                    callAsyncTask(function()
                                        info.func(var2)
                                    end)
                                end,
                            })
                            v.addOnChangeListener(
                                function(SeekBar, var2, var3)
                                    local v = luajava.astable(v.getValues())
                                    local v1 = v[1]
                                    local v2 = v[2]
                                    local Tag = SeekBar.getTag()
                                    local decimalPart = tostring(ShowingPage[Tag[1] + 1].stepSize):match("%.(%d+)")
                                    local decimalPlaces = decimalPart and #decimalPart or 0
                                    Tag[2].setText(string.format(
                                        decimalPlaces > 0 and ("%." .. decimalPlaces .. "f") or "%d", v1) ..
                                    '~' .. string.format(
                                        decimalPlaces > 0 and ("%." .. decimalPlaces .. "f") or "%d", v2))
                                end)
                        end,
                        layout_width = 'match_parent',
                        valueFrom = 1,
                        valueTo = 10,
                        values = {1,2},
                        stepSize = 1.0,
                    })
                }
            })
        elseif viewType == TYPE_SLIDER then
                view = luajava.loadlayout({
					LinearLayout,
					layout_width='match_parent',
					orientation='horizontal',
					gravity='center_vertical',
					{
                        LinearLayout,
                        layout_height='30dp',
                        layout_width = 'match_parent',
                        layout_marginTop = "2dp",
                        layout_marginBottom = "2dp",
                        gravity = "center_vertical",
                        {
                            TextView,
                            padding = { "14dp", "2dp", "0dp", "2dp", },
                            gravity = "top",
                            textColor = '#6B7280',
                            textSize = '12sp',
                            layout_width = 'wrap_content',
                            layout_marginRight = "0dp",
                            __onFinish = function(v)
                        if NoFont or alifont == nil then return end
                        v.setTypeface(alifont)
                            end,
                        },
                        {
                            TextView,
                            textColor='#6B7280',
                            layout_width='50dp',
                            textSize='12sp',
                            gravity='right|center_vertical',
                            layout_height='match_parent',
                            __onFinish = function(v)
                        if NoFont or alifont == nil then return end
                        v.setTypeface(alifont)
                            end,
                        },
                        loadlayout({
                            Slider,
                            thumbTrackGapSize='0dp',
                            thumbWidth='14dp',
                            trackHeight='4dp',
                            trackStopIndicatorSize='0dp',
                            tickVisible = false,
                            thumbHeight='18dp',
                            __onFinish = function(v)
                                v.setTrackActiveTintList(sldtktt)
                                v.setTrackInactiveTintList(sldiktt)
                                v.setLabelBehavior(2)
                                v.setCustomThumbDrawable(shizukuthumb2)
								v.addOnSliderTouchListener({
									onStopTrackingTouch=function(v)
										local var2=v.getValue()
										local Tag=v.getTag()[1]+1
                                        local info=ShowingPage[Tag]
                                        _ENV[info.id]=var2
										info.value = var2
                                        ViewMenus[SelectingNum][SecondPage[SelectingNum]][Tag]=info
                                        callAsyncTask(function()
                                            info.func(var2)
                                        end)
									end,
								})
                                v.addOnChangeListener(
                                function(SeekBar, var2, var3)
                                    local Tag=SeekBar.getTag()
                                    local info=ShowingPage[Tag[1]+1]
                                    local decimalPart = tostring(info.stepSize):match("%.(%d+)")
                                    local decimalPlaces = decimalPart and #decimalPart or 0
                                    Tag[2].setText(string.format(decimalPlaces > 0 and ("%." .. decimalPlaces .. "f") or "%d", var2)..info.level)
                                end)
                            end,
                            layout_width = 'match_parent',
                            valueFrom = 1,
                            valueTo = 10,
                            value = 1,
                            stepSize = 1.0,
                        })
                    }
				})
        elseif viewType == TYPE_EDIT then
			view= luajava.loadlayout({
				LinearLayout,
                layout_height = "wrap_content",
                layout_width = 'match_parent',
				gravity = "center_vertical",
                padding={'10dp','3dp','10dp','3dp'},
				{
					TextView,
					textColor = '#6B7280',
					textSize = "12sp",
					layout_height = "wrap_content",
					layout_width = "wrap_content",
					layout_marginRight = "6dp",
					gravity = 'center_vertical',
                    __onFinish = function(v)
                        if NoFont or alifont == nil then return end
                        v.setTypeface(alifont)
                    end,
				},
				{
					EditText,
					layout_width = 'match_parent',
					layout_height = '24dp',
					layout_weight=1,
					textSize = '12sp',
					textColor = '#6B7280',
					padding = {'10dp','-3dp','10dp','-3dp'},
					gravity='center',
                    focusableInTouchMode = true,
                        focusable = true,
                        cursorVisible = true,
                        inputType = 'text',
                    background = getBG(0xFFE3EFFB,10,3,0xFFEA4335),
                    __onFinish = function(v)

                    v.addTextChangedListener(luajava.createProxy('android.text.TextWatcher', {
                        beforeTextChanged = function(s, start, count, after) end,
                        onTextChanged = function(s, start, before, count) end,
                        afterTextChanged=function()
                            local t=tostring(v.getText())
                            local position=v.getTag()+1
                            EditTable[ViewMenus[SelectingNum][SecondPage[SelectingNum]][position].name] = t
                            ViewMenus[SelectingNum][SecondPage[SelectingNum]][position].value = t
                        end
                    }))
                    pcall(function()
                        v.setOnClickListener(luajava.createProxy('android.view.View$OnClickListener', {
                            onClick = function(view)
                                放开焦点()
                                view.requestFocus()
                            end
                        }))
                    end)
                    if NoFont or alifont == nil then return end
                        v.setTypeface(alifont)
					end,

				},
			})
        elseif viewType==TYPE_CHECKBOX then
            view = luajava.loadlayout({
                LinearLayout,
                layout_width='match_parent',
                layout_height='wrap_content',
                orientation='vertical',
                {
                    LinearLayout,
                    layout_width = "match_parent",
                    gravity = "center_vertical",
                    layout_margin = "1dp",
                    elevation='0dp',
                    layout_marginLeft='6dp',
                    layout_marginRight='6dp',
                    background = NovaBG(0xFFFFFFFF,10,NOVA.line,1),
                    padding="10dp",
                    onClick = function(v)
                        controlWater(v,120)
                        local Tag=v.getTag()+1
                        local info=ViewMenus[SelectingNum][SecondPage[SelectingNum]][Tag]
                        if info.isLoaded then
                            ViewMenus[SelectingNum][SecondPage[SelectingNum]][Tag].isLoaded=false
                            v.getParent().getChildAt(1).removeView(info.checklist)
                            v.getChildAt(1).setRotation(0)
                        else
                            ViewMenus[SelectingNum][SecondPage[SelectingNum]][Tag].isLoaded=true
                            v.getParent().getChildAt(1).addView(info.checklist)
                            v.getChildAt(1).setRotation(90)
                        end
                        ShowingPage[Tag]=ViewMenus[SelectingNum][SecondPage[SelectingNum]][Tag]
                    end,
                    {
                        TextView,
                        gravity='left',
                        textColor = '#6B7280',
                        textSize = "12sp",
                        layout_height = "wrap_content",
                        padding={'10dp','0dp','10dp','0dp'},
                        layout_weight=1,
                        layout_width = "match_parent",
                        __onFinish = function(v)
                        if NoFont or alifont == nil then return end
                        v.setTypeface(alifont)
                        end,
                    },{
                        ImageView,
                        layout_width='20dp',
                        layout_height='20dp',
                        src=SavePath..'heix',
                        layout_marginRight='10dp',
                        colorFilter=0xFF6B7280,
                    },
                },{
                    LinearLayout,
                    layout_width='match_parent',
                    layout_height='wrap_content',
                }
            })
        elseif viewType == TYPE_BOX then
            view = luajava.loadlayout({
                LinearLayout,
                layout_width='match_parent',
                layout_height='wrap_content',
                orientation='vertical',
                {
                    LinearLayout,
                    layout_width='match_parent',
                    layout_height='38dp',
                    gravity='center_vertical',
                    layout_margin='1dp',
                    background=NovaBG(0xFFFFFFFF,10,NOVA.line,1),
                    onClick=function(v)
                        local info=nil
                        pcall(function()
                            local tag=v.getTag()
                            if tag==nil then return end
                            local pos=nil
                            if type(tag)=='number' then pos=tag else pos=tonumber(tostring(tag)) end
                            if pos==nil then return end
                            info=ShowingPage[pos+1]
                        end)
                        if not info then return end
                        info.isOpen = not info.isOpen
                        pcall(function() controlWater(v,90) end)
                        local body=nil
                        pcall(function() body=v.getParent().getChildAt(1) end)
                        if info.isOpen then
                            NovaBuildBody(info, body)
                            if body then body.setVisibility(View.VISIBLE) end
                        else
                            if body then body.setVisibility(View.GONE) end
                        end
                        pcall(function() v.getChildAt(2).setText(info.isOpen and 'v' or '>') end)
                        pcall(function()
                            智能提示((info.name or '?')..' · '..tostring(#(info.items or {}))..' 款 · '..tostring(info.isOpen and '开' or '关'))
                        end)
                        pcall(function() if body then body.requestLayout() end end)
                        pcall(function() if body then body.invalidate() end end)
                        pcall(function()
                            local tag2=v.getTag()
                            local p2 = (type(tag2)=='number') and tag2 or tonumber(tostring(tag2))
                            if p2 then CAadapter.notifyItemChanged(p2) end
                        end)
                        pcall(function() recyclerView.requestLayout() end)
                        pcall(function() CAadapter.notifyDataSetChanged() end)
                    end,
                    { TextView, text='', textSize='13sp', textColor=0xFF161616,
                      layout_width='match_parent', layout_weight=1, layout_marginLeft='12dp' },
                    { TextView, text='', textSize='11sp', textColor=0xFF9CA3AF,
                      layout_marginRight='8dp' },
                    { TextView, text='>', textSize='13sp', textColor=0xFF6B7280,
                      layout_marginRight='12dp' },
                },
                {
                    LinearLayout,
                    layout_width='match_parent',
                    layout_height='wrap_content',
                    orientation='vertical',
                    padding={'0dp','2dp','0dp','6dp'},
                },
            })
        end
        -- 兜底：任何未知类型都不允许返回 nil
        if view == nil then
            view = luajava.loadlayout({
                TextView,
                layout_width = 'match_parent',
                layout_height = 'wrap_content',
                text = '',
                textSize = '13sp',
            })
        end
        return view
        end)
        if not __buildOk or __built == nil then
            pcall(function()
                local f = io.open(RootPath .. '/.uiview.log', 'a')
                if f ~= nil then
                    f:write('viewType=' .. tostring(viewType) .. ' ok=' .. tostring(__buildOk) .. ' err=' .. tostring(__built) .. string.char(10))
                    f:close()
                end
            end)
            __built = luajava.loadlayout({
                TextView,
                layout_width = 'match_parent',
                layout_height = 'wrap_content',
                text = '',
                textSize = '13sp',
            })
        end
        return __built
    end,
    bindView = function(holder, position)
        pcall(function()
        local info=ShowingPage[position+1]
        if info == nil then return end
        local viewType=info.type
        if viewType == nil then viewType = TYPE_TEXT end
        local itm=holder
		itm.setTag(position)
        if viewType == TYPE_BOX then
            local hdr = itm.getChildAt(0)
            local body = itm.getChildAt(1)
            hdr.setTag(position)
            hdr.getChildAt(0).setText(info.name or '')
            hdr.getChildAt(1).setText(info.sub or '')
            hdr.getChildAt(2).setText(info.isOpen and 'v' or '>')
            if info.isOpen then
                NovaBuildBody(info, body)
                body.setVisibility(View.VISIBLE)
            else
                body.setVisibility(View.GONE)
            end
        elseif viewType == TYPE_TEXT then
            itm.setText(info.name)
            itm.setTextSize(info.textSize)
            itm.setTextColor(info.color)
            itm.setGravity(info.isCenter and 0x11 or 0x13)
			itm.setTag(position)
        elseif viewType == TYPE_FRESHTEXT then
            itm.setText(info.name)
            itm.setTextColor(info.color)
			itm.setTag(position)
        elseif viewType == TYPE_IMAGE then

        elseif viewType == TYPE_CHECKBOX then
            local ck = itm.getChildAt(0)
            local rq = itm.getChildAt(1)
            local nr = rq.getChildAt(0)
            local pr = info.checklist.getParent()
            if nr ~= nil then
                rq.removeView(nr)
            end
            if pr ~= nil then
                pr.removeView(info.checklist)
            end
            ck.getChildAt(0).setText(info.name)
            if info.titleColor then ck.getChildAt(0).setTextColor(info.titleColor) end
            ck.setTag(position)
            if info.isLoaded then
                ck.getChildAt(1).setRotation(90)
                rq.addView(info.checklist)
            else
                ck.getChildAt(1).setRotation(0)
            end
        elseif viewType == TYPE_BUTTON then
			itm.getChildAt(0).setText(info.name)
			itm.setTag(position)
        elseif viewType == TYPE_SWITCH then
			local sw=itm.getChildAt(0)
            local ms=sw.getChildAt(1)
            sw.getChildAt(2).setTag(position)
            sw.getChildAt(2).setCheckedImmediatelyNoEvent(info.isChecked)
            sw.getChildAt(0).setText(info.name)
            if info.nameColor then sw.getChildAt(0).setTextColor(info.nameColor) end
            if info.noFont then
                sw.getChildAt(0).setTypeface(nil)
            else
                if not NoFont then
                    sw.getChildAt(0).setTypeface(alifont)
                end
            end
            if info.miaoshu==nil or info.miaoshu=='' then
                ms.setVisibility(View.GONE)
            else
                ms.setVisibility(View.VISIBLE)
                ms.setText(info.miaoshu)
            end
        elseif viewType == TYPE_EDIT then
			local btbg=itm
			local text=btbg.getChildAt(0)
			local edit=btbg.getChildAt(1)
			edit.setTag(position)
			edit.setText(info.value or '')
			edit.setHint(info.hint or '请输入内容')
			if info.name=="原皮数值" then 自改原皮控件=edit
			elseif info.name=="改皮数值" then 自改改皮控件=edit end
            text.setText(info.name)
			btbg.setTag(position)
        elseif viewType == TYPE_SLIDER then
			local slider = itm.getChildAt(0).getChildAt(2)
			local text = itm.getChildAt(0).getChildAt(0)
            local value= itm.getChildAt(0).getChildAt(1)
			slider.setTag({position,value})
			slider.setValueFrom(info.valueFrom or 1)
			slider.setValueTo(info.valueTo or 10)
			slider.setValue(info.value or 1)
			slider.setStepSize(info.stepSize or 1.0)
			text.setText(info.name)
			_ENV[info.id] = info.value or 1
        elseif viewType == TYPE_RANGE then
            local slider = itm.getChildAt(0).getChildAt(2)
            local text = itm.getChildAt(0).getChildAt(0)
            local value = itm.getChildAt(0).getChildAt(1)
            slider.setTag({ position, value })
            slider.setValueFrom(info.valueFrom or 1)
            slider.setValueTo(info.valueTo or 10)
            slider.setValues(info.value[1], info.value[2])
            slider.setStepSize(info.stepSize or 1.0)
            text.setText(info.name)
        end
        end)
    end,
})
CAadapter=BridgeRecyclerAdapter(luaImpl)

recyclerView.setAdapter(CAadapter)
for i=1,10 do
    RecycledPools.setMaxRecycledViews(i, 30)
end
recyclerView.setRecycledViewPool(RecycledPools)
recyclerView.setItemViewCacheSize(10)
function getTimeStamp(t)
    local str = os.date("%H:%M:%S ",t)
    return str
end
hanshu=function(v, event)
        local Action = event.getAction()
        if Action == MotionEvent.ACTION_DOWN then
            if mainLayoutParams.flags ~= LayoutParams.FLAG_NOT_FOCUSABLE then
                mainLayoutParams.flags = LayoutParams.FLAG_NOT_FOCUSABLE
                window.updateViewLayout(xfc, mainLayoutParams)
            end
            isVertical = (gg.getWindowOrientation() == 0)
            local need = false
            local w = Nova面板宽 or DP320
            local h = Nova面板高 or mainLayoutParams.height
            if mainLayoutParams.width ~= w then mainLayoutParams.width = w need = true end
            if h and mainLayoutParams.height ~= h then mainLayoutParams.height = h need = true end
            if need then window.updateViewLayout(xfc, mainLayoutParams) end
            maxheight = isVertical and math.max(dheight, dwidth) or math.min(dheight, dwidth)
            maxwidth = isVertical and math.min(dheight, dwidth) or math.max(dheight, dwidth)
            isMove = false
            StatuBarDP = (luajava.astable(starv.getLocationOnScreen())[2]-dheight/2)*2
            RawX = event.getRawX()
            RawY = event.getRawY()
            x = mainLayoutParams.x
            y = mainLayoutParams.y
            Nova拖末X = 0
            Nova拖末Y = 0
          elseif Action == MotionEvent.ACTION_MOVE then
            local dx = event.getRawX() - RawX
            local dy = event.getRawY() - RawY

            if math.abs(dx - (Nova拖末X or 0)) < 2 and math.abs(dy - (Nova拖末Y or 0)) < 2 then
                return true
            end
            Nova拖末X = dx
            Nova拖末Y = dy
            local halfWidth = mainLayoutParams.width / 2
            local halfHeight = mainLayoutParams.height / 2
            local screenCenterX = maxwidth / 2
            local screenCenterY = maxheight / 2
            isMove = true
            local nx = x + dx
            nx = math.max(-screenCenterX+halfWidth, math.min(nx, screenCenterX-halfWidth))
            local ny = y + dy
            ny = math.max(-screenCenterY+halfHeight+(isVertical and 0 or StatuBarDP/2), math.min(ny, screenCenterY-halfHeight-(isVertical and 0 or StatuBarDP/2)))
            if nx == mainLayoutParams.x and ny == mainLayoutParams.y then return true end
            mainLayoutParams.x = nx
            mainLayoutParams.y = ny
            window.updateViewLayout(xfc, mainLayoutParams)
        elseif Action == MotionEvent.ACTION_UP then
            if math.abs(mainLayoutParams.x - x) >= 10 or math.abs(mainLayoutParams.y - y) >= 10 then
                return true
            end
        end

end
luajava.newThread=function(fc)
    return {start=function() callAsyncTask(fc) end}
end
newThread=callAsyncTask
function 获取图片(txt)
ntxt = string.sub(string.gsub(txt,"/","-"),-10,-1)
if string.find(tostring(txt),"http") ~= nil then
if panduan(SavePath..ntxt) == false then
file.download(txt,SavePath..ntxt)
else
	if #file.read(SavePath..ntxt) <= 200 then
file.download(txt,SavePath..ntxt)
end
end
txt = SavePath..ntxt
end
return txt
end
function getRes(x)
return SavePath..x
end
luajava.getBitmapDrawable=function(x) bitmapDrawable(x) end
tuifunc=function(v)
    if Closing then return end
    Closing=true
	luajava.runOnUiThread(function()
        controlSmall(xfc,600,0.8)
        fadeout(xfc,600)
        callAsyncTask(function()
            gg.sleep(600)
            luajava.runUiThread(function()
                fadein(suspended_ball,200)
                xfqParams.flags = LayoutParams.FLAG_NOT_FOCUSABLE
                xfq.setVisibility(View.VISIBLE)
                xfc.setVisibility(View.GONE)
                显示=0
                Closing=false
            end)
        end)

        end)
    end
luajava.getIdValue=luajava.getIdView
显示=1
function sparkle_animation(view,time)
        local mObjectAnimator = ObjectAnimator.ofFloat(view, "alpha", 0, 1)
        mObjectAnimator.setDuration(time)
        mObjectAnimator.setInterpolator(DecelerateInterpolator())
        mObjectAnimator.start()
end
controlRotation9= function(view, time,t)
local mObjectAnimator = ObjectAnimator.ofFloat(view, "rotation", time,t)
        mObjectAnimator.setDuration(400)
        mObjectAnimator.start()
end
function zoom_animation(view,time)
        local dObjectAnimator = ObjectAnimator.ofFloat(view, "scaleX", 0, 1)
        dObjectAnimator.setDuration(time)
        dObjectAnimator.setInterpolator(DecelerateInterpolator())
        dObjectAnimator.start()
end
import("android.media.AudioManager")

audiotype = {
	AudioManager.STREAM_ALARM,
	AudioManager.STREAM_MUSIC,
	AudioManager.STREAM_NOTIFICATION,
	AudioManager.STREAM_RING,
	AudioManager.STREAM_SYSTEM,
	AudioManager.STREAM_VOICE_CALL,
	AudioManager.STREAM_DTMF,
}
yinl = {}
for i = 1,#audiotype do
yinl[i] = {}
yinl[i].type = audiotype[i]
yinl[i].min = audi.getStreamMinVolume(audiotype[i])
yinl[i].max = audi.getStreamMaxVolume(audiotype[i])
yinl[i].now = audi.getStreamVolume(audiotype[i])
end
yltype = 0
function jianting3(func)
yinln = {}
for i = 1,#audiotype do
yinln[i] = {}
yinln[i].type = audiotype[i]
yinln[i].now = audi.getStreamVolume(audiotype[i])
if yinln[i].now > yinl[i].now then
yinl[i].now = yinln[i].now
if yltype == 1 then
yltype = 0
func()
end
elseif yinln[i].now < yinl[i].now then
yinl[i].now = yinln[i].now
if yltype == 0 then
yltype = 1
func()
end
end
end
end
qhkai = 0
qiehuan = function()
if qhkai == 0 then
yinll = 0
qhkai = 1
	luajava.runUiThread(function()
			fadeout((显示==0 and xfq or xfc),500)
	end)
gg.sleep(500)
	luajava.runUiThread(function()
			(显示==0 and xfq or xfc).setVisibility(View.GONE)
	end)
else
	qhkai = 0
yinll = 1
	luajava.runUiThread(function()
        (显示==0 and xfq or xfc).setVisibility(View.VISIBLE)
			fadein((显示==0 and xfq or xfc),500)

	end)
end
end

function fadein(view,time)
    local mObjectAnimator = ObjectAnimator.ofFloat(view, "alpha", 0, 1)
    mObjectAnimator.setDuration(time)
    mObjectAnimator.setInterpolator(DecelerateInterpolator())
    mObjectAnimator.start()
end
function fadeout(view,time)
    local mObjectAnimator = ObjectAnimator.ofFloat(view, "alpha", 1, 0)
    mObjectAnimator.setDuration(time)
    mObjectAnimator.setInterpolator(DecelerateInterpolator())
    mObjectAnimator.start()
end
function getLayoutParams()
    LayoutParams = WindowManager.LayoutParams
    local layoutParams = luajava.new(LayoutParams)
    if (Build.VERSION.SDK_INT >= 26) then
        layoutParams.type = LayoutParams.TYPE_APPLICATION_OVERLAY
      else
        layoutParams.type = LayoutParams.TYPE_PHONE
    end
    layoutParams.format = PixelFormat.RGBA_8888
    layoutParams.flags = LayoutParams.FLAG_NOT_FOCUSABLE
    layoutParams.gravity = Gravity.CENTER
    layoutParams.width = LayoutParams.WRAP_CONTENT
    layoutParams.height = LayoutParams.WRAP_CONTENT
    return layoutParams
end
function getShepeBackground(color,radiu,bk1,bk2)
    local drawable = luajava.new(GradientDrawable)
    drawable.setShape(GradientDrawable.RECTANGLE)
    drawable.setColor(color)
    drawable.setCornerRadii({radiu,radiu,radiu,radiu,radiu,radiu,radiu,radiu})
    if bk1~=nil and bk2~=nil then drawable.setStroke(bk1,bk2) end
    return drawable
end
function getCorner(color,radiu1,radiu2,radiu3,radiu4)
    local drawable = luajava.new(GradientDrawable)
    drawable.setShape(GradientDrawable.RECTANGLE)
    drawable.setColor(color)
    drawable.setCornerRadii({radiu1,radiu1,radiu2,radiu2,radiu3,radiu3,radiu4,radiu4})
    return drawable
end

NOVA = {
  bg=0xFFFFFFFF, ink=0xFF161616, sub=0xFF6B7280, line=0xFFE6E6E6,
  faint=0xFFF5F5F5, accent=0xFFEA4335, soft=0xFFFDECEA,
  radius=14, radiusS=12, navW='88dp',
}
function NovaBG(fill, radius, stroke, strokeW)
  local d = GradientDrawable()
  d.setShape(0)
  d.setColor(fill or NOVA.bg)
  d.setCornerRadius(getpx((radius or NOVA.radius) .. 'dp'))
  d.setStroke(getpx((strokeW or 1) .. 'dp'), stroke or NOVA.line)
  return d
end
function NovaPill(on)
  if on then return NovaBG(0xFFFFFFFF, 8, NOVA.accent, 1) end
  return NovaBG(0x00FFFFFF, 8, 0x00FFFFFF, 1)
end

function NovaFlat() return NovaBG(0x00FFFFFF, 0, 0x00FFFFFF, 1) end

function getBG(colors, radiu, bk1, bk2)
  local r = NOVA.radius
  if type(radiu) == 'number' then r = radiu elseif type(radiu) == 'table' then r = radiu[1] or NOVA.radius end
  return NovaBG(NOVA.bg, r, NOVA.line, 1)
end
function getHorizontalBG(colors, radiu, bk1, bk2)
  local r = NOVA.radius
  if type(radiu) == 'number' then r = radiu elseif type(radiu) == 'table' then r = radiu[1] or NOVA.radius end
  return NovaBG(NOVA.bg, r, NOVA.line, 1)
end
function getShepeBackground(color, radiu, bk1, bk2)
  local r = NOVA.radius
  if type(radiu) == 'number' then r = radiu elseif type(radiu) == 'table' then r = radiu[1] or NOVA.radius end
  return NovaBG(color or NOVA.bg, r, NOVA.line, 1)
end

if NovaLT == nil then
  pcall(function() import 'android.animation.LayoutTransition' end)
  local ok, lt = pcall(function()
    local o = LayoutTransition()
    o.setDuration(220)
    return o
  end)
  if ok and lt ~= nil then NovaLT = lt else NovaLT = false end
end

function NovaLine(inset)
  return {
    View,
    layout_width='match_parent',
    layout_height='1dp',
    layout_marginLeft=(inset or '14dp'),
    layout_marginRight=(inset or '14dp'),
    background=NovaBG(0xFFEDEDED,0,0xFFEDEDED,0),
  }
end

function NovaGroup(title, children, opened)
  local cid='ng'..guid()
  local arrow={}
  local body={ LinearLayout, id=luajava.newId(cid), layout_width='match_parent',
    layout_height='wrap_content', orientation='vertical',
    visibility=(opened==false) and 'gone' or 'visible' }
  for i=1,#children do body[#body+1]=children[i] end
  local head={ LinearLayout, layout_width='match_parent', layout_height='38dp',
    gravity='center_vertical', layoutTransition=(NovaLT and NovaLT or nil),
    onClick=function(v)
      local b=nil
      pcall(function() b=luajava.getIdView(cid) end)
      if not b then return end
      local vis=tonumber(tostring(b.getVisibility()))
      if vis==8 then
        b.setVisibility(View.VISIBLE)
        pcall(function()
          local a=ObjectAnimator.ofFloat(arrow[1],'rotation',0,90)
          a.setDuration(180); a.setInterpolator(DecelerateInterpolator()); a.start()
        end)
      else
        b.setVisibility(View.GONE)
        pcall(function()
          local a=ObjectAnimator.ofFloat(arrow[1],'rotation',90,0)
          a.setDuration(200); a.start()
        end)
      end
    end,
    { TextView, text=title, textSize='12sp', textColor=0xFF6B7280,
      layout_width='match_parent', layout_weight=1, layout_marginLeft='14dp' },
    { TextView, text='>', textSize='15sp', textColor=0xFF9CA3AF, layout_marginRight='14dp',
      __onFinish=function(v) arrow[1]=v end },
  }
  return { LinearLayout, layout_width='match_parent', layout_height='wrap_content',
           orientation='vertical', layoutTransition=(NovaLT and NovaLT or nil), head, body }
end

function CAboxLite(name, items, sub)
  return { type=TYPE_BOX, name=name, items=items or {}, sub=sub or '',
           isOpen=false, built=false }
end
function NovaSkinRow(it)
  local color = it.color or 0xFF161616
  local row = {
    LinearLayout,
    layout_width='match_parent',
    layout_height='38dp',
    gravity='center_vertical',
    layout_margin='1dp',
    layout_marginLeft='10dp',
    layout_marginRight='8dp',
    background=NovaBG(0xFFFFFFFF,8,NOVA.line,1),
    { TextView, text=it.name, textSize='12.5sp', textColor=color,
      layout_width='match_parent', layout_weight=1, layout_marginLeft='10dp' },
    {
      SwitchButton,
      layout_width='40dp',
      layout_height='22dp',
      __onFinish=function(v)
        pcall(function()
          v.setBackRadius(999)
          v.setThumbRadius(999)
          v.setThumbColor(swcThumb)
          v.setBackColor(swcDraw)
          v.setThumbRangeRatio(1.7)
          v.setThumbMargin(marg)
        end)
        pcall(function() v.setCheckedImmediatelyNoEvent(it.on == true) end)
        pcall(function()
          v.setOnCheckedChangeListener({
            onCheckedChanged = function(vie, isc)
              it.on = isc and true or false
              if it.on then
                pcall(function() callAsyncTask(it.func or nothing) end)
              else
                pcall(function() if it.off then callAsyncTask(it.off) end end)
              end
            end
          })
        end)
      end,
    },
  }
  return row
end
function NovaBuildBody(info, body)
  if not body then return end
  local key = tostring(info.name)
  if body.getTag() == key then return end
  body.removeAllViews()
  local items = info.items or {}
  for i = 1, #items do
    local okrow, rowv = pcall(function() return luajava.loadlayout(NovaSkinRow(items[i])) end)
    if okrow and rowv then
      body.addView(rowv)
    else
      local tv = luajava.loadlayout({ TextView, text=tostring(items[i].name)..'（加载失败）',
        textSize='12sp', textColor=0xFFCC0000, layout_width='match_parent',
        layout_height='32dp', layout_marginLeft='14dp' })
      body.addView(tv)
    end
  end
  body.setTag(key)
end

Nova尺寸文件 = RootPath .. '/.nova_size'

function Nova保存面板尺寸(w, h)
    pcall(function()
        local f = io.open(Nova尺寸文件, 'w')
        if f then f:write(tostring(w) .. ',' .. tostring(h)) f:close() end
    end)
end

function Nova恢复面板尺寸()
    pcall(function()
        local f = io.open(Nova尺寸文件, 'r')
        if not f then return end
        local t = f:read('*a')
        f:close()
        local w, h = tostring(t):match('(%d+),(%d+)')
        w, h = tonumber(w), tonumber(h)
        if w and h and w > getpx('240dp') and h > getpx('260dp') then
            Nova面板宽, Nova面板高 = w, h
            mainLayoutParams.width = w
            mainLayoutParams.height = h
        end
    end)
end

function 面板拉伸监听(v)
    local st = { x = 0, y = 0, w = 0, h = 0 }
    v.setOnTouchListener(luajava.createProxy('android.view.View$OnTouchListener', {
        onTouch = function(view, e)
            local a = e.getAction()
            if a == 0 then
                st.x, st.y = e.getRawX(), e.getRawY()
                st.w, st.h = mainLayoutParams.width, mainLayoutParams.height
                st.ox, st.oy = mainLayoutParams.x, mainLayoutParams.y
                return true
            elseif a == 2 then
                local nw = st.w + (e.getRawX() - st.x)
                local nh = st.h + (e.getRawY() - st.y)
                local minW, minH = getpx('240dp'), getpx('260dp')
                if nw < minW then nw = minW end
                if nh < minH then nh = minH end
                nw, nh = math.floor(nw), math.floor(nh)

                mainLayoutParams.x = st.ox + math.floor((nw - st.w) / 2)
                mainLayoutParams.y = st.oy + math.floor((nh - st.h) / 2)
                Nova面板宽, Nova面板高 = nw, nh
                mainLayoutParams.width = nw
                mainLayoutParams.height = nh
                window.updateViewLayout(xfc, mainLayoutParams)
                return true
            elseif a == 1 or a == 3 then
                Nova保存面板尺寸(mainLayoutParams.width, mainLayoutParams.height)
                return true
            end
            return false
        end
    }))
end

Nova配置文件 = RootPath .. '/.nova_cfg.lua'

function Nova遍历开关(cb)
    for x, pages in pairs(ViewMenus or {}) do
        for y, items in pairs(pages) do
            if type(items) == 'table' then
                for i = 1, #items do
                    local it = items[i]
                    if type(it) == 'table' then
                        if it.type == TYPE_SWITCH then
                            cb(it, 'switch', x, y, i)
                        elseif it.type == TYPE_BOX and type(it.items) == 'table' then
                            for k = 1, #it.items do
                                local sub = it.items[k]
                                if type(sub) == 'table' and sub.name then
                                    cb(sub, 'box', x, y, i, k)
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

function Nova保存配置()
    local list = {}
    Nova遍历开关(function(it, kind)
        list[#list + 1] = { name = tostring(it.name), on = (kind == 'switch' and it.isChecked or it.on) and true or false }
    end)
    local ok = pcall(function()
        local f = io.open(Nova配置文件, 'w')
        f:write('return {\n')
        for i = 1, #list do
            f:write(string.format('{name=%q, on=%s},\n', list[i].name, list[i].on and 'true' or 'false'))
        end
        f:write('}\n')
        f:close()
    end)
    if ok then
        智能提示('配置已保存：' .. #list .. ' 项')
    else
        智能提示('保存失败，检查存储权限')
    end
end

function Nova读取配置()
    if not Nova就绪() then return end
    local ok, data = pcall(dofile, Nova配置文件)
    if not ok or type(data) ~= 'table' then
        智能提示('没有保存过的配置')
        return
    end
    local map = {}
    for i = 1, #data do
        if type(data[i]) == 'table' and data[i].name then
            map[tostring(data[i].name)] = data[i].on == true
        end
    end
    local 改 = 0
    Nova遍历开关(function(it, kind)
        local want = map[tostring(it.name)]
        if want == nil then return end
        if kind == 'switch' then
            if (it.isChecked and true or false) ~= want then
                it.isChecked = want
                改 = 改 + 1
                local fn = want and it.func1 or it.func2
                if type(fn) == 'function' then pcall(callAsyncTask, fn) end
            end
        else
            if (it.on and true or false) ~= want then
                it.on = want
                改 = 改 + 1
                local fn = want and it.func or it.off
                if type(fn) == 'function' then pcall(callAsyncTask, fn) end
            end
        end
    end)
    pcall(function() CAadapter.notifyDataSetChanged() end)
    智能提示('配置已套用：改动 ' .. 改 .. ' 项')
end

function Nova清空配置()
    pcall(function() os.remove(Nova配置文件) end)
    智能提示('配置已清空')
end

NovaCardUrl   = 'http://cysq.zh.kg/api.php'
NovaCardUrl2  = 'https://cysq.zh.kg/api.php'
NovaCardAppid = '752945'
NovaCardKey   = '9b9ecabb33010e9b78bb4bf7fd8088cd'
NovaCardImei  = RootPath .. '/.nova_imei'
NovaCardSave  = RootPath .. '/.nova_kami'
Nova已验      = false

function Nova转义(v)
    return (tostring(v):gsub('[^%w%-%._~]', function(c)
        return string.format('%%%02X', string.byte(c))
    end))
end
function Nova请求(query)
    local hosts = { NovaCardUrl, NovaCardUrl2 }
    local 细节 = {}
    for h = 1, #hosts do
        for i = 1, 3 do
            local r = Nova安全调用(gg.makeRequest, hosts[h] .. query)
            if type(r) == 'table' then
                local c = r.content
                local code = tostring(r.code or '')
                if c ~= nil and tostring(c) ~= '' and (code == '' or code == '200' or code == '0') then
                    Nova写日志('连接正常')
                    return r
                end
                细节[#细节 + 1] = 'HTTP ' .. (code ~= '' and code or '?')
            else
                细节[#细节 + 1] = '无返回'
            end
            gg.sleep(300 * i)
        end
    end
    Nova写日志('连接失败')
    return nil, table.concat(细节, '/')
end
function Nova机器码()
    local imei
    local f = io.open(NovaCardImei, 'r')
    if f then imei = f:read('*a') f:close() end
    if not imei or imei == '' then
        imei = tostring(os.time()) .. math.random(100000, 999999)
        pcall(function()
            local o = io.open(NovaCardImei, 'w')
            if o then o:write(imei) o:close() end
        end)
    end
    return imei
end

function Nova读上次卡密()
    local f = io.open(NovaCardSave, 'r')
    if not f then return '' end
    local t = f:read('*a') or ''
    f:close()
    return (t:gsub('%s', ''))
end

function Nova卡密请求(kami)
    local query = '?action=ext.kami_login&appid=' .. NovaCardAppid
        .. '&kami=' .. Nova转义(kami) .. '&imei=' .. Nova转义(Nova机器码())
    local r, why = Nova请求(query)
    if not r then return false, '网络错误（' .. tostring(why) .. '），切 WiFi/流量后重试' end
    local c = tostring(r.content)
    if not c:find('{', 1, true) then return false, '服务器返回异常，请稍后再试' end
    local code = c:match('"code":"(.-)"') or ''
    local msg  = c:match('"msg":"(.*)","now_time"') or c:match('"msg":"(.-)"') or ''
    local now  = tonumber(c:match('"now_time":"(.-)"') or '') or os.time()
    local vip  = tonumber(c:match('"vip_time":"(.-)"') or '') or 0
    local left = c:match('"left_count":"(.-)"') or ''
    local sign = c:match('"md5_check":"(.-)"') or ''
    msg = msg:gsub('\\n', '\n')
    if math.abs(now - os.time()) > 300 then return false, '数据过期，请校准手机时间' end
    if type(md5) == 'function' and sign ~= '' then
        local okSign, mine = pcall(md5, code .. now .. NovaCardKey)
        if okSign and tostring(mine) ~= sign then return false, '签名校验失败，联系管理员' end
    end
    if code == '6' then
        local tip
        if vip >= 4000000000 then tip = '永久卡（长期有效）'
        elseif vip > 0 then tip = '到期：' .. os.date('%Y-%m-%d %H:%M', vip)
        elseif left ~= '' then tip = '次数卡（剩余 ' .. left .. ' 次）'
        else tip = '次数卡' end
        pcall(function()
            local o = io.open(NovaCardSave, 'w')
            if o then o:write(kami) o:close() end
        end)
        return true, tip
    end
    return false, (msg ~= '' and msg or ('code=' .. tostring(code)))
end

function Nova读自动登录()
    local f = io.open(RootPath .. '/.nova_auto', 'r')
    if not f then return true end
    local t = (f:read('*a') or ''):gsub('%s', '')
    f:close()
    return t ~= '0'
end

function Nova写自动登录(on)
    pcall(function()
        local o = io.open(RootPath .. '/.nova_auto', 'w')
        if o then o:write(on and '1' or '0') o:close() end
    end)
end

function Nova公告请求()
    local r = Nova请求('?action=ext.app_announcement&appid=' .. NovaCardAppid)
    if not r then return '' end
    local c = tostring(r.content)
    local msg = c:match('"msg":"(.*)","now_time"') or c:match('"msg":"(.-)"') or ''
    msg = msg:gsub('\\n', '\n'):gsub('\\t', '  ')
    return msg
end

function Nova设备解绑(kami)
    local query = '?action=ext.imei_relieve&appid=' .. NovaCardAppid
        .. '&kami=' .. Nova转义(kami) .. '&imei=' .. Nova转义(Nova机器码())
    local r, why = Nova请求(query)
    if not r then return false, '网络错误（' .. tostring(why) .. '），切 WiFi/流量后重试' end
    local c = tostring(r.content)
    local code = c:match('"code":"(.-)"') or ''
    local msg = (c:match('"msg":"(.*)","now_time"') or c:match('"msg":"(.-)"') or ''):gsub('\\n', '\n')
    if code == '10' then
        return true, (msg ~= '' and msg or '解绑成功')
    end
    return false, (msg ~= '' and msg or ('code=' .. tostring(code)))
end

function Nova卡密输入法(v)
    if v == nil then return end

    pcall(function()
        mainLayoutParams.flags = LayoutParams.FLAG_NOT_TOUCH_MODAL
        window.updateViewLayout(xfc, mainLayoutParams)
    end)
    luajava.runOnUiThread(function()
        pcall(function()
            v.setFocusable(true)
            v.setFocusableInTouchMode(true)
            v.requestFocus()
        end)
        pcall(function()
            local imm = context.getSystemService('input_method')
            if imm then imm.showSoftInput(v, 0) end
        end)
    end)
end

function Nova关输入法(v)
    pcall(function()
        local imm = context.getSystemService('input_method')
        if imm and v ~= nil then imm.hideSoftInputFromWindow(v.getWindowToken(), 0) end
    end)
    pcall(function()
        mainLayoutParams.flags = LayoutParams.FLAG_NOT_FOCUSABLE
        window.updateViewLayout(xfc, mainLayoutParams)
    end)
end

function Nova让可拖(handle, target)
    local st = { x = 0, y = 0, tx = 0, ty = 0 }
    pcall(function()
        handle.setOnTouchListener(luajava.createProxy('android.view.View$OnTouchListener', {
            onTouch = function(v, e)
                local a = e.getAction()
                if a == 0 then
                    st.x, st.y = e.getRawX(), e.getRawY()
                    st.tx, st.ty = target.getTranslationX(), target.getTranslationY()
                    return true
                elseif a == 2 then
                    target.setTranslationX(st.tx + (e.getRawX() - st.x))
                    target.setTranslationY(st.ty + (e.getRawY() - st.y))
                    return true
                end
                return false
            end
        }))
    end)
end

function Nova掩盖卡密(k)
    k = tostring(k or '')
    if #k <= 8 then return k end
    return k:sub(1, 4) .. '****' .. k:sub(-4)
end

function Nova构建卡密层()
    local box = luajava.loadlayout({
        FrameLayout,
        layout_width = 'match_parent',
        layout_height = 'match_parent',
        background = NovaBG(0xFFFFFFFF, 14, NOVA.line, 1),
        clickable = true,
        {
            ScrollView,
            layout_width = 'match_parent',
            layout_height = 'match_parent',
            __onFinish = function(v)
                pcall(function() v.setVerticalScrollBarEnabled(false) end)
            end,
            {
            LinearLayout,
            id = luajava.newId('NovaKamiCard'),
            orientation = 'vertical',
            layout_width = 'match_parent',
            layout_height = 'wrap_content',
            padding = '18dp',
            background = NovaBG(0x00FFFFFF, 0, 0x00FFFFFF, 0),
            {
                TextView,
                text = 'Nova',
                id = luajava.newId('NovaKamiTitle'),
                textSize = '24sp',
                textColor = NOVA.ink,
                gravity = 'center',
                layout_width = 'match_parent',
            },
            {
                TextView,
                text = '卡 密 验 证',
                textSize = '11sp',
                textColor = NOVA.sub,
                gravity = 'center',
                layout_width = 'match_parent',
                layout_marginTop = '4dp',
            },
            {
                LinearLayout,
                layout_width = 'match_parent',
                layout_height = '1dp',
                layout_marginTop = '16dp',
                background = NovaBG(NOVA.line, 0, NOVA.line, 0),
            },
            {
                ScrollView,
                id = luajava.newId('NovaKamiNoticeBox'),
                layout_width = 'match_parent',
                layout_height = '54dp',
                layout_marginTop = '12dp',
                background = NovaBG(0xFFFAFAFA, 10, 0xFFEEEEEE, 1),
                padding = '10dp',
                __onFinish = function(v)
                    pcall(function() v.setVerticalScrollBarEnabled(false) end)
                end,
                {
                    TextView,
                    id = luajava.newId('NovaKamiNotice'),
                    text = '正在读取公告…',
                    textSize = '11sp',
                    textColor = NOVA.sub,
                    layout_width = 'match_parent',
                    layout_height = 'wrap_content',
                },
            },
            {
                EditText,
                hint = '请输入卡密',
                id = luajava.newId('NovaKamiInput'),
                layout_width = 'match_parent',
                layout_height = '46dp',
                layout_marginTop = '12dp',
                padding = '14dp',
                textSize = '13sp',
                text = '',
                includeFontPadding = false,
                minHeight = '0dp',
                singleLine = true,
                gravity = 'center_vertical',
                background = NovaBG(0xFFF7F7F7, 12, 0xFFE6E6E6, 1),
                textColor = 0xFF161616,
                focusableInTouchMode = true,
                focusable = true,
                cursorVisible = true,
                inputType = 'text',
                onClick = function(v)
                    Nova卡密输入法(v)
                end,
                __onFinish = function(v)
                    pcall(function()
                        v.setIncludeFontPadding(false)
                        v.setMinHeight(0)
                        v.setMinimumHeight(0)
                        v.setPadding(getpx('14dp'), 0, getpx('14dp'), 0)
                        v.setGravity(0x10)
                    end)
                    v.setHintTextColor(0xFF9CA3AF)
                end,
            },
            {
                TextView,
                id = luajava.newId('NovaKamiMsg'),
                text = '卡密会记住，下次自动登录',
                textSize = '11sp',
                textColor = NOVA.sub,
                layout_width = 'match_parent',
                layout_marginTop = '10dp',
            },
            {
                LinearLayout,
                layout_width = 'match_parent',
                layout_height = '40dp',
                orientation = 'horizontal',
                gravity = 'center',
                layout_marginTop = '6dp',
                {
                    TextView,
                    text = '自动登录',
                    textSize = '12sp',
                    textColor = NOVA.sub,
                    layout_width = 'wrap_content',
                    layout_height = 'wrap_content',
                    layout_marginRight = '8dp',
                },
                {
                    SwitchButton,
                    id = luajava.newId('NovaKamiAuto'),
                    layout_width = 'wrap_content',
                    layout_height = 'wrap_content',
                    __onFinish = function(v)
                        pcall(function()
                            v.setBackRadius(999)
                            v.setThumbRadius(999)
                            v.setThumbRangeRatio(1.7)
                            if swcThumb ~= nil then v.setThumbColor(swcThumb) end
                            if swcDraw ~= nil then v.setBackColor(swcDraw) end
                            if marg ~= nil then v.setThumbMargin(marg) end
                        end)
                    end,
                },
            },
            {
                LinearLayout,
                id = luajava.newId('NovaKamiBtn'),
                layout_width = 'match_parent',
                layout_height = '44dp',
                layout_marginTop = '10dp',
                background = NovaBG(NOVA.accent, 12, NOVA.accent, 1),
                gravity = 'center',
                clickable = true,
                {
                    TextView,
                    text = '验 证 并 进 入',
                    textSize = '14sp',
                    textColor = 0xFFFFFFFF,
                    gravity = 'center',
                    layout_width = 'match_parent',
                    layout_height = 'match_parent',
                },
            },
            {
                LinearLayout,
                id = luajava.newId('NovaKamiUnbind'),
                layout_width = 'match_parent',
                layout_height = '40dp',
                layout_marginTop = '10dp',
                gravity = 'center',
                clickable = true,
                background = NovaBG(0xFFFFFFFF, 10, NOVA.line, 1),
                {
                    TextView,
                    text = '解 绑 设 备',
                    textSize = '12sp',
                    textColor = NOVA.sub,
                    gravity = 'center',
                    layout_width = 'match_parent',
                    layout_height = 'match_parent',
                },
            },
            {
                TextView,
                id = luajava.newId('NovaKamiQuit'),
                text = '退出',
                textSize = '12sp',
                textColor = NOVA.sub,
                gravity = 'center',
                layout_width = 'match_parent',
                layout_height = '38dp',
                layout_marginTop = '4dp',
                clickable = true,
            },
            },
        },
    })
    return box
end

function Nova构建卡密层极简()
    local box = luajava.loadlayout({
        FrameLayout,
        layout_width = 'match_parent',
        layout_height = 'match_parent',
        background = NovaBG(0xFFFFFFFF, 14, NOVA.line, 1),
        clickable = true,
        {
            LinearLayout,
            id = luajava.newId('NovaKamiCard'),
            orientation = 'vertical',
            layout_width = 'match_parent',
            layout_height = 'wrap_content',
            layout_gravity = 'center',
            padding = '22dp',
            {
                TextView,
                text = 'Nova',
                textSize = '24sp',
                textColor = NOVA.ink,
                gravity = 'center',
                layout_width = 'match_parent',
            },
            {
                TextView,
                text = '卡 密 验 证',
                textSize = '11sp',
                textColor = NOVA.sub,
                gravity = 'center',
                layout_width = 'match_parent',
                layout_marginTop = '4dp',
            },
            {
                EditText,
                hint = '请输入卡密',
                id = luajava.newId('NovaKamiInput'),
                layout_width = 'match_parent',
                layout_height = '48dp',
                layout_marginTop = '18dp',
                padding = '14dp',
                textSize = '13sp',
                singleLine = true,
                includeFontPadding = false,
                minHeight = '0dp',
                gravity = 'center_vertical',
                background = NovaBG(0xFFF7F7F7, 12, 0xFFE6E6E6, 1),
                textColor = 0xFF161616,
                focusableInTouchMode = true,
                focusable = true,
                cursorVisible = true,
                inputType = 'text',
                onClick = function(v) Nova卡密输入法(v) end,
                __onFinish = function(v)
                    pcall(function()
                        v.setIncludeFontPadding(false)
                        v.setMinHeight(0)
                        v.setMinimumHeight(0)
                        v.setPadding(getpx('14dp'), 0, getpx('14dp'), 0)
                        v.setGravity(0x10)
                    end)
                    v.setTextColor(0xFF161616)
                    v.setHintTextColor(0xFF9CA3AF)
                end,
            },
            {
                TextView,
                id = luajava.newId('NovaKamiMsg'),
                text = '输入卡密后点下方按钮',
                textSize = '11sp',
                textColor = NOVA.sub,
                layout_width = 'match_parent',
                layout_marginTop = '10dp',
            },
            {
                LinearLayout,
                id = luajava.newId('NovaKamiBtn'),
                layout_width = 'match_parent',
                layout_height = '46dp',
                layout_marginTop = '14dp',
                background = NovaBG(NOVA.accent, 12, NOVA.accent, 1),
                gravity = 'center',
                clickable = true,
                {
                    TextView,
                    text = '验 证 并 进 入',
                    textSize = '14sp',
                    textColor = 0xFFFFFFFF,
                    gravity = 'center',
                },
            },
            {
                TextView,
                id = luajava.newId('NovaKamiQuit'),
                text = '退出',
                textSize = '12sp',
                textColor = NOVA.sub,
                gravity = 'center',
                layout_width = 'match_parent',
                layout_height = '40dp',
                layout_marginTop = '6dp',
                clickable = true,
            },
        },
    })
    return box
end

function Nova收起卡密层(box)
    local card = luajava.getIdView('NovaKamiCard')
    pcall(function() box.animate().alpha(0).setDuration(180).start() end)
    pcall(function() card.animate().scaleX(0.92).scaleY(0.92).alpha(0).setDuration(220).start() end)
    callAsyncTask(function()
        gg.sleep(240)
        luajava.runUiThread(function()
            pcall(function()
                if Nova卡窗口 ~= nil then window.removeView(Nova卡窗口) end
            end)
            pcall(function() xfc.removeView(box) end)
            Nova卡窗口 = nil
            Nova卡窗口参数 = nil
            pcall(function()
                mainLayoutParams.width = Nova门旧宽 or Nova面板宽 or DP320
                mainLayoutParams.height = Nova门旧高 or Nova面板高 or DP280
                window.updateViewLayout(xfc, mainLayoutParams)
            end)
            pcall(function() xfq.setVisibility(View.VISIBLE) end)
            pcall(function() xfc.setAlpha(1) end)
            pcall(function()
                local body = luajava.getIdView('ooo')
                if body ~= nil then
                    body.setAlpha(1)
                    body.setVisibility(View.VISIBLE)
                end
            end)
            Nova已验 = true
        end)
    end)
end

function Nova绑定卡密层(box)
    local input = luajava.getIdView('NovaKamiInput')
    local msgv  = luajava.getIdView('NovaKamiMsg')
    local btn   = luajava.getIdView('NovaKamiBtn')
    local quit  = luajava.getIdView('NovaKamiQuit')

    local function setMsg(t, red)
        luajava.runUiThread(function()
            pcall(function()
                msgv.setText(tostring(t))
                msgv.setTextColor(red and NOVA.accent or NOVA.sub)
            end)
        end)
    end

    local function 取值()
        local t = ''
        pcall(function() t = tostring(input.getText()) end)
        return (t:gsub('%s', ''))
    end

    local submit = function()
        local k = 取值()
        if k == '' then setMsg('卡密不能为空', true) return end
        Nova关输入法(input)
        setMsg('正在校验…', false)
        callAsyncTask(function()
            local ok, info = Nova卡密请求(k)
            if ok then
                setMsg('验证成功：' .. tostring(info), false)
                gg.sleep(300)
                Nova收起卡密层(box)
            else
                setMsg(tostring(info), true)
            end
        end)
    end

    pcall(function() input.setOnClickListener(function(v) Nova卡密输入法(v) end) end)
    pcall(function()
        input.setOnTouchListener(luajava.createProxy('android.view.View$OnTouchListener', {
            onTouch = function(v, e)
                if e.getAction() == 0 then Nova卡密输入法(v) end
                return false
            end
        }))
    end)

    callAsyncTask(function()
        gg.sleep(300)
        local txt = Nova公告请求()
        if txt == nil or txt == '' then txt = '暂无公告' end
        luajava.runUiThread(function()
            pcall(function()
                local nv = luajava.getIdView('NovaKamiNotice')
                if nv then nv.setText(txt) end
            end)
        end)
    end)

    pcall(function()
        local unb = luajava.getIdView('NovaKamiUnbind')
        if unb == nil then return end
        unb.setOnClickListener(function()
            Nova关输入法(input)
            callAsyncTask(function()
                local okp, r = pcall(gg.prompt, { '输入要解绑的卡密：\n（解绑后可在新设备登录）' },
                    { 取值() }, { 'text' })
                if not okp or r == nil or r[1] == nil then return end
                local k = (tostring(r[1]):gsub('%s', ''))
                if k == '' then return end
                setMsg('正在解绑…', false)
                local ok, info = Nova设备解绑(k)
                if ok then
                    setMsg('解绑成功：' .. tostring(info), false)
                    gg.alert('解绑成功\n' .. tostring(info) .. '\n\n请重新运行脚本并输入卡密')
                    pcall(function() os.remove(NovaCardSave) end)
                else
                    setMsg('解绑失败：' .. tostring(info), true)
                    gg.alert('解绑失败\n' .. tostring(info))
                end
            end)
        end)
    end)

    pcall(function() btn.setOnClickListener(function() submit() end) end)
    pcall(function()
        quit.setOnClickListener(function()
            Nova关输入法(input)
            UIQuit = 1
        end)
    end)

    pcall(function()
        local sw = luajava.getIdView('NovaKamiAuto')
        if sw == nil then return end
        sw.isChecked = Nova读自动登录()
        sw.setOnCheckedChangeListener({
            onCheckedChanged = function(v2, isc)
                Nova写自动登录(isc and true or false)
                setMsg(isc and '已开启自动登录' or '已关闭自动登录，下次需手动输入', false)
            end
        })
    end)

    local saved = Nova读上次卡密() or ''

    if saved ~= '' then
        pcall(function() input.setText(saved) end)
    end
    if saved ~= '' and Nova读自动登录() then
        callAsyncTask(function()
            gg.sleep(420)
            setMsg('正在自动登录…', false)
            local ok, info = Nova卡密请求(saved)
            if ok then
                setMsg('自动登录成功：' .. tostring(info), false)
                gg.sleep(260)
                Nova收起卡密层(box)
            else
                setMsg('自动登录未成功（' .. tostring(info) .. '），可点验证重试', true)
            end
        end)
    end
end

function Nova弹出卡密层()
    local box = nil
    local okB, b1 = pcall(Nova构建卡密层)
    if okB and b1 ~= nil then box = b1 end
    if box == nil then
        pcall(function() Nova写日志('卡密层构建失败，走极简兜底: ' .. tostring(b1) .. '') end)
        local okC, b2 = pcall(Nova构建卡密层极简)
        if okC and b2 ~= nil then box = b2 end
    end
    if box == nil then
        智能提示('卡密页加载失败，看 .nova_log.txt')
        return false
    end
    Nova卡视图 = box
    pcall(Nova绑定卡密层, box)

    local okA, errA = pcall(function()
        luajava.runOnUiThread(function()
            local ok2, err2 = pcall(function()
                xfc.addView(box)
                pcall(function() xfc.bringChildToFront(box) end)
            end)
            if not ok2 then
                pcall(function() Nova写日志('卡密层 addView 失败: ' .. tostring(err2)) end)
            end
        end)
    end)
    if not okA then
        pcall(function() Nova写日志('卡密层挂载异常: ' .. tostring(errA)) end)
    end
    pcall(function() Nova写日志('卡密遮罩已挂载(面板内全屏)') end)
    return true
end

function uistart(sview)
    FenyeS={}
	if not xfc_height then xfc_height="470dp" end
	gg.hide(true)
    pages={}
    LeftSelect={
        LinearLayout;
        onClick=function() end,
        layout_height="match_parent";
        orientation="vertical";
        layout_width="88dp";
        background=NovaBG(0xFFFAFAFA,13,0xFFFFFFFF,0),
        layout_marginLeft='1dp',
        layout_marginTop='1dp',
        layout_marginBottom='1dp',
        padding={"0dp","6dp","0dp","6dp"},
        gravity='center'
    }
    ViewMenus={}
    Sliders={}
    FreshTexts={}
    SecondPage={}
    SelectingNum=1
    TopSelect={
                        LinearLayout,
                        layout_width="match_parent",
                        layout_marginRight='2dp',

                        gravity="center_vertical",
                        background=NovaFlat(),
                        layout_margin='6dp',
                        layout_marginLeft='4dp',
                        layout_marginBottom='0dp',
                    }
    TopBG={}
    SelectedBG=getBG(NOVA.accent,20)
    NoSelectedBG=getBG(0xFF8EA0C7,30)
    for i=1,#sview do
        TopBG[i]={}
        ViewMenus[i]={}
        SecondPage[i]=1
        local TopList={
            LinearLayout,
            layout_width="match_parent",
        }
        FenyeS[i]={['二级分页']={}}
        for j=1,#sview[i]['二级分页'] do
            TopBG[i][j]={NovaPill(false),NovaPill(true)}
            FenyeS[i]['二级分页'][j]={['分页列数']=sview[i]['二级分页'][j]['分页列数'] or 1}
            ViewMenus[i][j]={}
            table.insert(TopList,{
                LinearLayout,
                layout_height="wrap_content",
                orientation="vertical",
                onClick=function(v)
                    TurnPage(i,j)
                end,
                {
                    TextView,
                    text=sview[i]['二级分页'][j]['分页名字'],
                    textSize="12.5sp",
                    gravity="center",
                    id=luajava.newId(i..'TopSelect'..j),
                    layout_gravity="center",
                    layout_marginBottom="3dp",
                    layout_marginTop="5dp",
                    layout_marginLeft="3dp",
                    layout_marginRight="3dp",
                    padding={"13dp","5dp","13dp","5dp"},
                    background=j==1 and TopBG[i][j][2] or TopBG[i][j][1],
                    textColor=(j==1 and '#EA4335' or '#6B7280'),
                    __onFinish = function(v)
                        if NoFont or alifont == nil then return end

                        v.setTypeface(alifont)
                    end,
                },
            })
        	local 菜单源=sview[i]['二级分页'][j]['分页菜单']
        	if type(菜单源)=="function" then
        	    FenyeS[i]['二级分页'][j]['懒加载']=菜单源
        	else
        	for k=1,#菜单源 do
                local m=菜单源[k]
                if m.type==TYPE_SLIDER then
                    Sliders[m.id]={i,j,k}
                elseif m.type==TYPE_FRESHTEXT then
                    FreshTexts[m.id]={i,j,k}
                end
        	    ViewMenus[i][j][k]=m
        	end
        	end
        end
        table.insert(TopSelect,{
            HorizontalScrollView,
            layout_weight=1,
            layout_width="match_parent",
            id=luajava.newId('SecondPage'..i),
            visibility=i==1 and 'visible' or 'gone',
            TopList
        })
        LeftSelect[#LeftSelect+1]={
			LinearLayout,
			gravity="center",
			layout_height = "38dp",
            layout_marginLeft='6dp',
            layout_marginRight='6dp',
            layout_margin='2dp',
            elevation='0dp',
            background=NovaBG(0xFFFFFFFF,10,NOVA.line,1),
            id=luajava.newId('left_text_layout_'..i),
            layout_width = "match_parent",
			onClick=function() TurnPage(i) end,
			__onFinish=function(v)

			end,
			{
                TextView,
                id=luajava.newId("jm"..i.."t"),
                text=sview[i]["分区名字"],
                gravity = "center",
                textSize = "13sp",
                textColor = i==1 and NOVA.accent or 0xFF4B5563,
                layout_width = "match_parent",
                layout_weight=1,
                __onFinish = function(v)
                        if NoFont or alifont == nil then return end
                        v.setTypeface(alifont)
                end,
			}
		}
    end
    ShowingPage=ViewMenus[1][1]
    xfc = {
        FrameLayout;
        layout_height="fill";
        id="touch";
        layout_width="fill";
        elevation='0dp',
        background=NovaBG(0xFFFFFFFF,14,NOVA.line,1),
        __onFinish=function(v)
            pcall(function() v.setClipToOutline(true) end)
            pcall(function() v.setClipChildren(true) end)
        end,
        {
            LinearLayout;
            layout_height='match_parent';
            orientation="horizontal";
            id="ooo";
            layout_width='match_parent';
            onClick=function() end,
            onTouch=hanshu,
            {
                LinearLayout;
                layout_height="match_parent";
                layout_width="wrap_content";
                orientation='vertical',
                id='jms',
                onClick=function() end,
                onTouch=hanshu,
                {
                    LinearLayout,
                    layout_width='wrap_content',
                    layout_height='match_parent',
                    orientation='horizontal',
                    gravity='left',
                    background=getBG(0xffffffff,{20,0,0,20}),
                    {
                        LinearLayout,
                        layout_width='match_parent',
                        layout_height="match_parent";
                        orientation='vertical',
                        gravity='center_horizontal',
                        {
                            MaterialCardView,
                            layout_width='match_parent',
                            layout_marginTop='0dp',
                            layout_height='44dp',
                            useCompatPadding=false,
                            cardElevation='0dp',
                            cardBackgroundColor=0xffffffff,
                            strokeColor=0x00FFFFFF,
                            onClick=tuifunc,
                            onTouch=hanshu,
                            __onFinish=function(v)
                                v.setRadius(0)
                                local c=ColorStateList({{android.R.attr.state_pressed},{-android.R.attr.state_pressed}}, {0x00ffffff,0x00ffffff})
                                v.setRippleColor(c)
                            end,
                            {
                                LinearLayout,
                                layout_width='88dp',
                                layout_height='wrap_content',
                                orientation='vertical',
                                gravity='center_horizontal',
                                {
                                    ImageView,
                                    layout_width='88dp',
                                    layout_height='0dp',
                                    src=SavePath..'nachosleep2',
                                    visibility='gone',
                                    padding='-1dp',
                                },
                                {
                                    TextView,
                                    layout_width='match_parent',
                                    layout_height='44dp',
                                    padding={'14dp','0dp','14dp','0dp'},
                                    gravity='center_vertical',
                                    textSize='15sp',
                                    textColor='#161616',
                                    text=标题,
                                    __onFinish = function(v)
                                        if NoFont or alifont == nil then return end
                                        v.setTypeface(alifont)
                                    end,
                                },
                                {
                                    View,
                                    layout_width='match_parent',
                                    layout_height='1dp',
                                    background=NovaBG(0xFFEDEDED,0,0xFFEDEDED,0),
                                },
                            }
                        },

                        {
                            ScrollView;
                            layout_width="wrap_content";
                            layout_margin='4dp',
                            layout_marginTop='2dp',
                            layout_marginBottom='2dp',

                            padding={'0dp','0dp','0dp','0dp'},
                            VerticalScrollBarEnabled=false;
                            layout_weight=1,
                            id=luajava.newId('PageLeftScroll'),
                            layout_height="match_parent";
                            LeftSelect;
                        };

                    },
                },

            };

            {
                LinearLayout;
                layout_height="match_parent";
                layout_weight=1,
                layout_width="match_parent";
                orientation='vertical',
{
                            LinearLayout,
                            layout_width = 'match_parent',
                            layout_height = '36dp',
                            layout_margin='0dp',
                            layout_marginLeft='8dp',
                            layout_marginRight='8dp',
                            layout_marginTop='6dp',
                            layout_marginBottom='4dp',
                            elevation='0dp',
                            padding = '0dp',
                            orientation = 'horizontal',
                            gravity = 'center_vertical',
                            background = NovaBG(0xFFFFFFFF,10,NOVA.line,1),
                            {
                                ImageView,
                                layout_width = '16dp',
                                layout_height = '16dp',
                                layout_marginLeft = '10dp',
                                layout_marginRight = '6dp',
                                padding = '0dp',
                                colorFilter = 0xFF9CA3AF,
                                src = SavePath .. 'sou',
                                onClick = function()
                                    local t = tostring(luajava.getIdView('searchi').getText())
                                    if t == '' or t == nil then return 0 end
                                    SearchInAll(t)
                                end,
                                onTouch = hanshu,
                            },
                            {
                                EditText,
                                hint = '搜索功能 / 皮肤',
                                layout_width = 'match_parent',
                                layout_height = 'match_parent',
                                layout_weight = 1,
                                padding = '0dp',
                                textSize = '13sp',
                                text = '',
                                includeFontPadding = false,
                                minHeight = '0dp',
                                singleLine = true,
                                gravity = 'center_vertical',
                                id = luajava.newId('searchi'),
                                background = NovaFlat(),
                                textColor = 0xFF161616,
                                focusableInTouchMode = true,
                                focusable = true,
                                cursorVisible = true,
                                inputType = 'text',
                                onClick=function(v)
                                    mainLayoutParams.flags=LayoutParams.FLAG_NOT_TOUCH_MODAL
                                    window.updateViewLayout(xfc,mainLayoutParams)
                                end,
                                __onFinish = function(v)
                                    pcall(function()
                                        v.setIncludeFontPadding(false)
                                        v.setPadding(0,0,0,0)
                                        v.setMinHeight(0)
                                        v.setMinimumHeight(0)
                                        v.setGravity(0x10)
                                    end)
                                    v.setHintTextColor(0xFF9CA3AF)
                                    v.addTextChangedListener(luajava.createProxy('android.text.TextWatcher', {
                                        beforeTextChanged = function(s, start, count, after) end,
                                        onTextChanged = function(s, start, before, count) end,
                                        afterTextChanged=function()
                                            local t = tostring(v.getText())
                                            if t:find('\n') ~= nil then
                                                SearchInAll(t)
                                            end
                                        end
                                    }))
                                    if NoFont or alifont == nil then return end
                                v.setTypeface(alifont)
                                end,
                            },
                        },
                TopSelect,
                {
                    LinearLayout,
                    layout_height='match_parent',
                    layout_width='match_parent',
                    layout_weight=1,
                    {
                        LinearLayout,
                        layout_margin='8dp',
                        layout_marginLeft='4dp',
                        layout_marginRight='2dp',
                        layout_marginTop=-6,
                        layout_width='match_parent',
                        layout_height='match_parent',
                        background=NovaFlat(),
                        padding=4,
                        recyclerView
                    },
                },
            };
            {
                LinearLayout,
                layout_width='0dp',
                layout_height='match_parent',
                orientation='vertical',
                gravity='center_horizontal',
                onClick=function(v)

                end,
                onTouch=hanshu,
                {
                    ImageView,
                    layout_width = "40dp",
                    layout_height = "20dp",
                    src = SavePath .. 'heix',
                    visibility='gone',
                    onClick = tuifunc,
                    padding='3dp',
                    layout_marginTop='8dp',
                    onTouch = hanshu,
                    colorFilter = 0xffBDBAC9,
                    background=getBG(0x00BDBAC9,20,6,0xffBDBAC9),
                },
            },

        };
        {
            FrameLayout,
            layout_width='0dp',
            layout_height='0dp',
            layout_gravity='right|bottom',
            {
                ImageView,
                layout_width='match_parent',
                layout_height='match_parent',
                src=SavePath..'gcmm',
            },
            {
                TextView,
                layout_width='wrap_content',
                layout_height='wrap_content',
                gravity='center',
                id=luajava.newId('timestamp'),
                textSize='8sp',
                layout_marginTop='80dp',
                layout_marginLeft='3dp',
                layout_gravity='center_horizontal',
                rotation=4,
                textColor='#2C2A38',
                text=getTimeStamp(),
                __onFinish=function(v)
                    if NoFont or alifont == nil then return end
                    v.setTypeface(alifont)
                end,
            },
        },
        ViewFakeTransition
    }

    xfq = {
        LinearLayout;
        layout_height="fill";
        layout_width="fill";
        id = "suspended_ball",
        visibility='gone',
        onClick = function(v)
            if Closing then return end
            Closing = true
            xfq.setVisibility(View.GONE)
            controlBig(xfc, 400, 0.8)
            fadein(xfc, 400)
            mainLayoutParams.flags = LayoutParams.FLAG_NOT_FOCUSABLE
            mainLayoutParams.height = Nova面板高 or DP280
            mainLayoutParams.width = Nova面板宽 or DP320
            xfc.setVisibility(View.VISIBLE)
            callAsyncTask(function()
                gg.sleep(400)
                Closing = false
                显示=1
            end)
        end,
        onTouch=function(v, event)
            local Action = event.getAction()
            if Action == MotionEvent.ACTION_DOWN then
                isMove = false
                RawX = event.getRawX()
                RawY = event.getRawY()
                x = xfqParams.x
                y = xfqParams.y
              elseif Action == MotionEvent.ACTION_MOVE then
                isMove = true
                xfqParams.x = tonumber(x) + (event.getRawX() - RawX)
                xfqParams.y = tonumber(y) + (event.getRawY() - RawY)
                window.updateViewLayout(xfq, xfqParams)
            elseif Action == MotionEvent.ACTION_UP then
                if math.abs(xfqParams.x - x) >= 10 or math.abs(xfqParams.y - y) >= 10 then
                    return true
                end
            end
        end,
        {
            LinearLayout;
            {
                ImageView;
                layout_width="40dp";
                src=SavePath..'cb3ff1.jpg';
                layout_height="40dp";
                padding='2dp',
            };
        };
    };

    mainLayoutParams = getLayoutParams()
    xfqParams=getLayoutParams()
    xfqParams.gravity = Gravity.LEFT | Gravity.TOP
    xfq = loadlayout(xfq)
    xfc = loadlayout(xfc)
    pcall(function()
        local grip = luajava.loadlayout({
            FrameLayout,
            layout_width = '30dp',
            layout_height = '30dp',
            layout_gravity = 'right|bottom',
            layout_margin = '4dp',
            background = NovaBG(0xFFF5F5F5, 8, NOVA.line, 1),
            {
                TextView,
                text = '◢',
                textSize = '11sp',
                textColor = NOVA.sub,
                gravity = 'center',
                layout_width = 'match_parent',
                layout_height = 'match_parent',
            },
        })
        xfc.addView(grip)
        Nova拉伸监听 = grip
        面板拉伸监听(grip)
    end)
    luajava.runOnUiThread(invoke)
    local Nova秒视图 = nil
    local Nova上次秒 = ''
    while true do
        gg.sleep(600)
        local nowSec = os.date('%H:%M:%S')
        if nowSec ~= Nova上次秒 then
            Nova上次秒 = nowSec
            luajava.runUiThread(function()
                if Nova秒视图 == nil then Nova秒视图 = luajava.getIdView('timestamp') end
                if Nova秒视图 ~= nil then pcall(function() Nova秒视图.setText(nowSec) end) end
            end)
        end
        if 音量键 then jianting3(qiehuan) end
        if UIQuit==1 then break end
    end
        luajava.runOnUiThread(function()
        end)
end
function invoke()

    pcall(function() xfc.setAlpha(0) end)
    mainLayoutParams.flags = LayoutParams.FLAG_NOT_FOCUSABLE
    mainLayoutParams.width=getpx(gg.getWindowOrientation()==0 and DP320 or DP320)
    mainLayoutParams.height=DP280
    pcall(function() Nova恢复面板尺寸() end)
    pcall(function()
        if Nova面板宽 == nil or Nova面板高 == nil then Nova应用尺寸() end
    end)
    pcall(function()
        mainLayoutParams.width = Nova面板宽 or mainLayoutParams.width
        mainLayoutParams.height = Nova面板高 or mainLayoutParams.height
    end)
    window.addView(xfc, mainLayoutParams)
    window.addView(xfq, xfqParams)
    local wm = getLayoutParams()
        wm.flags = LayoutParams.FLAG_NOT_FOCUSABLE
        window.addView(luajava.loadlayout({
            LinearLayout,
            __onFinish = function(v)
                starv = v
            end
        }), wm)
    TurnPage(1)

    local NovaBody = nil
    pcall(function()
        NovaBody = luajava.getIdView('ooo')
        if NovaBody ~= nil then NovaBody.setVisibility(View.INVISIBLE) end
    end)
    pcall(function() xfq.setVisibility(View.GONE) end)

    -- 卡密验证已整段去掉：这里不再调用 Nova弹出卡密层，进去直接就是面板
    pcall(function()
        if NovaBody ~= nil then
            NovaBody.setVisibility(View.VISIBLE)
            NovaBody.setAlpha(1)
        end
    end)
    pcall(function() xfq.setVisibility(View.VISIBLE) end)
    pcall(function() sparkle_animation(xfc,180) end)

    luajava.runOnUiThread(function()
        pcall(function()
            xfc.setVisibility(View.VISIBLE)
            xfc.setAlpha(1)
        end)
    end)
end

switches = {}

local ver = luajava.bindClass("android.os.Build").VERSION.SDK_INT;
function setBackground(view,bg)
  if ver<16 then
    view.setBackgroundDrawable(bg)
   else
    view.setBackground(bg)
  end
end

function CALoadV2(func1,func2)
    func1= func1 or nothing
    func2= func2 or nothing
    local v=MaterialSwitch(M3context)
    v.setOnCheckedChangeListener({
    onCheckedChanged=function(view,isc)
        if isc then
            callAsyncTask(func1)
        else
            callAsyncTask(func2)
        end
    end
    })
    v.setChecked(false)
    v.setTextOn('')
    v.setTextOff('')
    v.setThumbIconSize(getpx('12dp'))
    v.setTrackDecorationTintList(swctrack)
    v.setTrackTintList(swcDraw)
    v.setThumbTintList(swcThumb)
    v.setText('')
    v.setLayoutParams(LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,
    getpx('30dp')
))
    return v

end
function CAswitch(name,func1,func2,miaoshu)
return {
            name=name,
            type=TYPE_SWITCH,
            func1=func1,
            func2=func2,
            miaoshu=miaoshu or '',
            isChecked= false,
        }
end
function CAswitch2(name,func1,func2,miaoshu)
return {
            name=name,
            type=TYPE_SWITCH,
            func1=func1,
            func2=func2,
            miaoshu=miaoshu or '',
            isChecked= NoFont,
            noFont=true,
        }
end
EditTable={}
function CAEdit(name, hint)
    return {
        name = name or '编辑框',
        type = TYPE_EDIT,
        value = '',
        hint = hint or '请输入',
    }
end
function CAGetEdit(name)
    return tostring(EditTable[name])
end
function controlWater(view,time)
    local dObjectAnimator = ObjectAnimator.ofFloat(view, "scaleX",1, 0.95 ,1)
        dObjectAnimator.setDuration(time)
        dObjectAnimator.setInterpolator(DecelerateInterpolator())
        dObjectAnimator.start()
        local dObjectAnimator = ObjectAnimator.ofFloat(view, "scaleY", 1, 0.95, 1)
        dObjectAnimator.setDuration(time)
        dObjectAnimator.setInterpolator(DecelerateInterpolator())
        dObjectAnimator.start()
end
controlBig = function(view,time,startP)
    local dObjectAnimator
    if startP then
        dObjectAnimator = ObjectAnimator.ofFloat(view, "scaleX",startP,1)
    else
        dObjectAnimator = ObjectAnimator.ofFloat(view, "scaleX",0, 0.4, 0.7, 1)
    end
        dObjectAnimator.setDuration(time)
        dObjectAnimator.setInterpolator(DecelerateInterpolator())
        dObjectAnimator.start()
        if startP then
        dObjectAnimator = ObjectAnimator.ofFloat(view, "scaleY",startP,1)
        else
            dObjectAnimator = ObjectAnimator.ofFloat(view, "scaleY",0, 0.4, 0.7, 1)
        end
        dObjectAnimator.setDuration(time)
        dObjectAnimator.setInterpolator(DecelerateInterpolator())
        dObjectAnimator.start()
end
controlSmall = function(view,time,startP)
    local dObjectAnimator
    if startP then
        dObjectAnimator = ObjectAnimator.ofFloat(view, "scaleX",1,startP)
    else
        dObjectAnimator = ObjectAnimator.ofFloat(view, "scaleX",0, 0.4, 0.7, 1)
    end
        dObjectAnimator.setDuration(time)
        dObjectAnimator.setInterpolator(DecelerateInterpolator())
        dObjectAnimator.start()
        if startP then
        dObjectAnimator = ObjectAnimator.ofFloat(view, "scaleY",1,startP)
        else
            dObjectAnimator = ObjectAnimator.ofFloat(view, "scaleY",0, 0.4, 0.7, 1)
        end
        dObjectAnimator.setDuration(time)
        dObjectAnimator.setInterpolator(DecelerateInterpolator())
        dObjectAnimator.start()
end
nothing=function() end
function CAseek(name,bian,smin,smax,nows,stepSize,level,func)
return {
            name=name,
            type=TYPE_SLIDER,
            id=bian,
            valueFrom=smin,
            valueTo=smax,
            value=nows,
            level=level,
			stepSize=stepSize,
            func=func,
            defaultValue=nows
        }
end
function CARange(name, bian, smin, smax, nows, stepSize, func)
    return {
        name = name,
        type = TYPE_RANGE,
        id = bian,
        valueFrom = smin,
        valueTo = smax,
        value = nows,
        stepSize = stepSize,
        func = func,
        defaultValue = nows
    }
end
function CAbutton(name,func)
    if type(func) == 'function' then
        local 原 = func
        func = function(...)
            if Nova脱敏 == nil then return pcall(原, ...) end
            local ok, err = pcall(原, ...)
            if not ok then
                Nova写日志('执行异常')
                智能提示('执行异常')
            end
        end
    end
    return {
        type=TYPE_BUTTON,
        name=name,
        func=func
    }
end
KGlist={}
function 开关(name,func1,func2)
    name = name..guid()
    KGlist[name] = false
    if func1 == nil then func1 = "" end
    if func2 == nil then func2 = "" end
    if type(func1) == "function" then
        local outfunc=function()
            local kg = KGlist[name]
            if not kg then
                KGlist[name] = true
                pcall(func1)
              else
                KGlist[name] = false
                pcall(func2)
            end
        end
        return outfunc
    end
end
function CAintcheck(name,func1,func2,color)
    nid = name..guid()
    local func = 开关(name,func1,func2,nid)
    if not name then name = "未设置" end
    local rstt={
            LinearLayout,
            layout_width = 'match_parent',
            layout_height = "wrap_content",
            gravity = "center_vertical",
            layout_weight=1,
            {
                LinearLayout,
                layout_width = 'fill_parent',
                layout_height = "wrap_content",
                gravity = "center_vertical",
                layout_marginTop='2dp',
                layout_marginBottom='2dp',
                layout_marginLeft='2dp',
                layout_marginRight='2dp',
                padding = {
                    "6dp","4dp","2dp","4dp"
                },
                {
                    TextView,
                    gravity = "top",
                    text = name,
                    textColor = color or "#667AAA",
                    textSize = "12sp",
                    layout_width = 'match_parent',
                    layout_weight=1,
                    layout_marginRight = "0dp",
                    __onFinish = function(v)
                        if NoFont or alifont == nil then return end
                        v.setTypeface(alifont)
                    end,
                },
                {
                    CheckBox,
                    layout_gravity = "center",
                    onClick = function() callAsyncTask(func) end,
                    __onFinish=function(v)
                        v.setButtonTintList(RadTint)
                    end,
                }}
        }

    return rstt
    end
function CAcheck(name,cklist)
local forsearch={}
    local rest = {
        LinearLayout,
        layout_width = 'match_parent',
        layout_height = "wrap_content",
        padding={"6dp","2dp","6dp","2dp"},
        gravity = "center",
        orientation="vertical",

    }

    for i = 1, #cklist,2 do
    local tempTable = {LinearLayout,
        layout_width = 'fill_parent',
        layout_height = "wrap_content",
        gravity = "left",
        orientation="horizontal"
    }
    for j = 0, 1 do
    if cklist[i + j] ~= nil then
    local name = cklist[i + j][1]
    table.insert(forsearch,name)
    local func1 = cklist[i + j][2]
    local func2 = cklist[i + j][3]
    if not name then name = "未设置" end
    rstt = CAintcheck(name,func1,func2,cklist[i+j][4])
    table.insert(tempTable, rstt)
    else
        table.insert(tempTable, {LinearLayout,
        layout_width = 'match_parent',
        layout_weight=1})
    end
    end
    table.insert(rest, tempTable)
    end
    return {
        type=TYPE_CHECKBOX,
        name=name,
        isLoaded=false,
        checklist=loadlayout(rest),
        forsearch=forsearch
    }
end
function CAtext(txt,color,size,isjz)
return {
            name=txt,
            type=TYPE_TEXT,
            color=color or 0xff161616,
            textSize=size or 13,
            isCenter= isjz or false,
        }
end
function CAFreshText(txt,id,color,size,isjz)
return {
            name=txt,
            id=id,
            type=TYPE_FRESHTEXT,
            color=color or 0xff161616,
            textSize=size or '13sp',
            isCenter= isjz or false,
        }
end
gg.setVisible(false)

function init() ttitle=标题 xfcpic=悬浮窗图标 end

function CAradio(cklist)
    local rest = {
        LinearLayout ,
        layout_width = 'match_parent' ,
        layout_height = "wrap_content" ,
        orientation = "vertical" ,

    }
    if type (cklist [1]) == "string" then
        rds=2
    rest [# rest + 1] = {
        TextView ,
        gravity = "left" ,
        padding="5dp",
        text = cklist [1] ,
        textSize = "13sp" ,
            textColor = 0xffeeeeee,
        layout_width = 'match_parent' ,
        layout_height = 'wrap_content' ,
        layout_marginLeft = "10dp" ,
        layout_marginRight = "5dp" ,
        layout_marginTop = "0dp" ,
        layout_marginBottom = "0dp" ,
        __onFinish = function(v)
            if NoFont or alifont == nil then return end
            v.setTypeface(alifont)
        end,
    }
    else
        rds=1
    end
    local restt={
        RadioGroup ,
        layout_width = 'match_parent' ,
        layout_height = "wrap_content" ,
        layout_margin = "4dp" ,
        gravity = "top" ,
        orientation = "vertical" ,
        elevation='2dp',
        background=getBG({0x33333333,0x33333333},10),
    }
    for i = rds , # cklist do
    local name = cklist [i] [1]
    local func = cklist [i] [2]
    if not name then
    name = "未设置"
    end
    local nid = name..guid ()
    restt [# restt + 1] = {
            RadioButton ,
            text = name ,
            textSize="13sp",
            gravity='center_vertical',
            textColor = 0xffeeeeee,
            layout_width = 'match_parent' ,
            layout_height = 'wrap_content' ,
            layout_marginLeft = "2dp" ,
            layout_marginRight = "2dp" ,
            __onFinish=function(v)

                v.setButtonTintList(RadTint)
                if NoFont or alifont == nil then return end
            v.setTypeface(alifont)
            end,
            onClick=function()
                callAsyncTask(func)
            end
        }
    end
    rest [# rest + 1] = restt
    return rest
    end

function ResetSliders(...)
    local t={...}
    for a,b in pairs(t) do
        local tb=Sliders[b]
        if tb~=nil then
            local va=ShowingPage[tb[3]].defaultValue
            ViewMenus[tb[1]][tb[2]][tb[3]].value=va
            ShowingPage[tb[3]].value=va
        end
    end
    luajava.runOnUiThread(function()
         CAadapter.notifyDataSetChanged()
    end)
end

function SetSliders(t,value)
    for a,b in pairs(t) do
        local tb=Sliders[b]
        if tb~=nil then
            ViewMenus[tb[1]][tb[2]][tb[3]].value=value
            ShowingPage[tb[3]].value=value
        end
    end
    luajava.runOnUiThread(function()
         CAadapter.notifyDataSetChanged()
    end)
end

function SetText(t,text)
        local tb=FreshTexts[t]
        if tb~=nil then
            ViewMenus[tb[1]][tb[2]][tb[3]].name=text
            ShowingPage[tb[3]].name=text
        end
    luajava.runOnUiThread(function()
         CAadapter.notifyDataSetChanged()
    end)
end
function luajava.getBitmap(x)
    return BitmapFactory.decodeFile(x)
end

function SearchInAll(text)
    luajava.runUiThread(function()
        luajava.getIdView('SecondPage'..SelectingNum).setVisibility(View.GONE)
    end)
    ShowingPage={}
    for k, v in pairs(ViewMenus) do
        for j, l in pairs(v) do
            for c, b in pairs(l) do
                if b.type ~= TYPE_FRESHTEXT and b.type ~= TYPE_TEXT and b.type ~= TYPE_CHECKBOX then
                    if string.find(b.name, text) ~= nil then
                        local fenqu = 分页[k]['分区名字']
                        local fenye = 分页[k]['二级分页'][j]['分页名字']
                        table.insert(ShowingPage, CAbutton(fenqu .. '-' .. fenye .. ' 第' .. c .. '项  [ ' .. b.name ..
                        ' ]', function()
                            luajava.runOnUiThread(function()
                                luajava.getIdView('SecondPage' .. SelectingNum).setVisibility(View.VISIBLE)
                                TurnPage(k, j, c - 1)
                            end)
                        end))
                    end
                elseif b.type == TYPE_CHECKBOX then
                    for i,n in pairs(b.forsearch) do
                        if string.find(n, text) ~= nil then
                            local fenqu = 分页[k]['分区名字']
                            local fenye = 分页[k]['二级分页'][j]['分页名字']
                            table.insert(ShowingPage, CAbutton(fenqu .. '-' .. fenye .. ' 勾选：  [ ' .. n ..
                            ' ]', function()
                                ViewMenus[k][j][c].isLoaded=true
                                luajava.runOnUiThread(function()
                                    luajava.getIdView('SecondPage' .. SelectingNum).setVisibility(View.VISIBLE)
                                    TurnPage(k, j, c - 1)
                                end)
                            end))
                        end
                    end
                end
            end
        end
    end
    if #ShowingPage==0 then
        table.insert(ShowingPage,CAtext('未搜索到包含“'..text..'”的功能'))
    else
        table.insert(ShowingPage,1,CAtext('搜索到包含“'..text..'”的功能有'..#ShowingPage..'项'))
    end
    luajava.runOnUiThread(function()
        recyclerView.setLayoutManager(layoutmanager[1])
         CAadapter.notifyDataSetChanged()
    end)
end

标题='NOVA'
悬浮窗图标='https://yuju.99kpk.top:81/pan/1981/WHNB7891__cb3ff1.jpg'

------------------------------------------------------------------ 设备适配（手机 / 平板自动调尺寸）
Nova设备 = { 平板 = false, sw = 0, 宽dp = 0, 高dp = 0, 密度 = 1, 描述 = '' }
function Nova设备检测()
  local dm = activity.getResources().getDisplayMetrics()
  local cfg = activity.getResources().getConfiguration()
  Nova设备.密度 = dm.density
  Nova设备.宽dp = math.floor(dm.widthPixels / dm.density + 0.5)
  Nova设备.高dp = math.floor(dm.heightPixels / dm.density + 0.5)
  local sw = 0
  pcall(function() sw = cfg.smallestScreenWidthDp end)
  Nova设备.sw = sw or math.min(Nova设备.宽dp, Nova设备.高dp)
  Nova设备.平板 = (Nova设备.sw >= 600) or (Nova设备.宽dp >= 600 and Nova设备.高dp >= 960)
  Nova设备.描述 = string.format('%s · sw=%ddp · %d×%ddp',
    Nova设备.平板 and '平板' or '手机', Nova设备.sw, Nova设备.宽dp, Nova设备.高dp)
  return Nova设备.平板
end
function Nova尺寸计算(模式)
  Nova设备检测()
  local 平板 = Nova设备.平板
  if 模式 == 'phone' then 平板 = false end
  if 模式 == 'tablet' then 平板 = true end
  local 限宽 = Nova设备.宽dp - 24
  local 限高 = Nova设备.高dp - 140
  local w, h
  if 平板 then
    w = math.min(720, math.floor(限宽 * 0.62))
    h = math.min(1180, math.floor(限高 * 0.86))
  else
    w = math.min(430, 限宽)
    h = math.min(900, math.floor(限高 * 0.80))
  end
  if w < 300 then w = 300 end
  if h < 340 then h = 340 end
  return w, h
end
function Nova应用尺寸(模式)
  local w, h = Nova尺寸计算(模式)
  Nova面板宽 = getpx(w)
  Nova面板高 = getpx(h)
  pcall(function()
    if mainLayoutParams ~= nil then
      mainLayoutParams.width = Nova面板宽
      mainLayoutParams.height = Nova面板高
      if xfc ~= nil then window.updateViewLayout(xfc, mainLayoutParams) end
    end
  end)
  pcall(function() Nova保存面板尺寸(Nova面板宽, Nova面板高) end)
  return w, h
end
function Nova适配提示(模式)
  local w, h = Nova应用尺寸(模式)
  Nova设备检测()
  智能提示((Nova设备.平板 and '平板' or '手机') .. '：' .. w .. '×' .. h .. 'dp')
end
--------------------------------------------------------------------------------
-- 示例版补齐：这两个函数在原文件里属于业务区（被裁掉了），这里给个空实现，
-- 免得保留下来的 pcall 里调用到 nil。
--------------------------------------------------------------------------------
function Nova写日志(msg) end
function Nova脱敏(e) return tostring(e) end

--------------------------------------------------------------------------------
-- 演示菜单：整个界面的内容全部在这里，改这里就等于改界面
--------------------------------------------------------------------------------
分页 = {
    {
        ["分区名字"] = "控件",
        ["二级分页"] = {
            {
                ["分页名字"] = "基础",
                ['分页列数'] = 1,
                ["分页菜单"] = {
                    CAtext("一、文字", 0xFF1D1D1F, 15),
                    CAtext("这是普通文字，13sp 深灰", 0xFF1D1D1F, 13),
                    CAtext("这是红色文字 14sp", 0xFFCC0000, 14),
                    CAtext("这行是居中的", 0xFF6B7280, 12, true),

                    CAtext("二、按键", 0xFF1D1D1F, 15),
                    CAbutton("普通按钮（点了弹提示）", function() 提示("你点了按钮") end),
                    CAbutton("按钮也能执行任意函数", function()
                        提示("函数里可以写任何代码")
                    end),

                    CAtext("三、开关", 0xFF1D1D1F, 15),
                    CAswitch("开关演示", function() 提示("已打开") end, function() 提示("已关闭") end, "副标题在这"),

                    CAtext("四、输入框", 0xFF1D1D1F, 15),
                    CAEdit("输入框演示", "在这里输入内容"),
                    CAbutton("读取输入框的值", function()
                        提示("内容 = " .. CAGetEdit("输入框演示"))
                    end),
                }
            },
            {
                ["分页名字"] = "滑块",
                ['分页列数'] = 1,
                ["分页菜单"] = {
                    CAtext("滑块（拖动实时回调）", 0xFF1D1D1F, 14),
                    CAFreshText("当前值 = 50", "demo_seek_txt", 0xFF6B7280, 12),
                    CAseek("数值滑块", "demo_seek", 0, 100, 50, 1, nil, function(v)
                        SetText("demo_seek_txt", "当前值 = " .. tostring(v))
                    end),

                    CAtext("范围滑块", 0xFF1D1D1F, 14),
                    CAFreshText("当前值 = 5", "demo_range_txt", 0xFF6B7280, 12),
                    CARange("范围滑块", "demo_range", 0, 10, 5, 1, function(v)
                        SetText("demo_range_txt", "当前值 = " .. tostring(v))
                    end),
                }
            },
            {
                ["分页名字"] = "分组",
                ['分页列数'] = 1,
                ["分页菜单"] = {
                    CAtext("折叠分组：点标题展开 / 收起", 0xFF1D1D1F, 14),
                    CAboxLite("分组一", {
                        { name = "子项 A", func = function() 提示("子项 A") end },
                        { name = "子项 B", func = function() 提示("子项 B") end },
                        { name = "子项 C（带关闭回调）",
                          func = function() 提示("打开") end,
                          off = function() 提示("关闭") end },
                    }, "3 项"),
                    CAboxLite("分组二", {
                        { name = "只有一个子项", func = function() 提示("ok") end },
                    }, "1 项"),

                    CAtext("注：CAcheck / CAradio / CAintcheck 返回的是“布局 table”（[1]=LinearLayout），", 0xFF6B7280, 12),
                    CAtext("不要直接写进分页菜单，否则取不到 type 会崩。它们要用在自定义 createView 里，", 0xFF6B7280, 12),
                    CAtext("或者包一层 { LinearLayout, ... , CAcheck(...) } 当普通布局塞进去。", 0xFF6B7280, 12),
                }
            },
        }
    },
    {
        ["分区名字"] = "两列",
        ["二级分页"] = {
            {
                ["分页名字"] = "网格",
                ['分页列数'] = 2,
                ["分页菜单"] = {
                    CAbutton("按钮 1", function() 提示("1") end),
                    CAbutton("按钮 2", function() 提示("2") end),
                    CAbutton("按钮 3", function() 提示("3") end),
                    CAbutton("按钮 4", function() 提示("4") end),
                    CAbutton("按钮 5", function() 提示("5") end),
                    CAbutton("按钮 6", function() 提示("6") end),
                }
            },
        }
    },
    {
        ["分区名字"] = "怎么写",
        ["二级分页"] = {
            {
                ["分页名字"] = "填内容",
                ['分页列数'] = 1,
                ["分页菜单"] = {
                    CAtext("改界面只需要改上面那个 分页 表", 0xFF1D1D1F, 14),
                    CAtext("1. 分区名字 → 左侧导航的文字", 0xFF6B7280, 12),
                    CAtext("2. 二级分页 → 顶部 tab", 0xFF6B7280, 12),
                    CAtext("3. 分页菜单 → 这一页从上往下排的控件", 0xFF6B7280, 12),
                    CAtext("4. 分页列数 = 1 单列，= 2 两列网格", 0xFF6B7280, 12),
                    CAtext(" "),
                    CAtext("加一个控件：", 0xFF1D1D1F, 14),
                    CAtext('CAtext("说明", 0xFF6B7280, 12),', 0xFF0057B8, 12),
                    CAtext('CAbutton("按钮", function() 提示("hi") end),', 0xFF0057B8, 12),
                    CAtext(" "),
                    CAtext("加一个分区：复制整段 { [\"分区名字\"] = ..., [\"二级分页\"] = {...} } 进来", 0xFF6B7280, 12),
                    CAtext(" "),
                    CAtext("全新控件类型：见文件开头注释第四节", 0xFF6B7280, 12),
                }
            },
        }
    },
    {
        ["分区名字"] = "关于",
        ["二级分页"] = {
            {
                ["分页名字"] = "关于",
                ['分页列数'] = 1,
                ["分页菜单"] = {
                    CAtext("最开始的 Nova UI", 0xFF1D1D1F, 18),
                    CAtext("纯 UI 示例（无玻璃 / 无模糊 / 无折射）", 0xFF6B7280, 12),
                    CAtext("只保留界面框架与控件演示", 0xFF6B7280, 12),
                    CAbutton("点我测试按钮回调", function() 提示("UI 正常") end),
                }
            },
        }
    },
}

local Nova启动ok, Nova启动err = xpcall(function()
    uistart(分页)
end, function(e) return tostring(e) end)
if not Nova启动ok then
    智能提示('启动异常：' .. tostring(Nova启动err))
end
